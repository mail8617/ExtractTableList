
**  FE_MK_PRMTN_ORD_SL ���۾��� �ʿ������
TRUNCATE TABLE FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT2 ; 

** ����������
INSERT /*+ APPEND PARALLEL(T 4) */
  INTO FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT2 T
SELECT /*+ PARALLEL(4) */ DISTINCT T1.STD_DT
     , T1.PRMTNCD
     , T1.INTG_MEMB_NO
     , T2.PRMTN_STRT_DT
     , T2.PRMTN_END_DT
     , SYSDATE     AS LOAD_DTTM
  FROM
     (
        SELECT /*+ PARALLEL(4) */
               STD_DT
             , PRMTNCD
             , INTG_MEMB_NO
          FROM FE_MK_PRMTN_ORD_SL  /* FE_MK_����ֹ��ӽ� */
         WHERE INTG_MEMB_NO IS NOT NULL AND DLR_TOT_NSALAMT > 0
     ) T1
 INNER JOIN D_PRMTN T2
    ON T1.PRMTNCD = T2.PRMTNCD
;
-- 34735045   2M50S 20240217���� 
O_COUNT := SQL%ROWCOUNT;
COMMIT;

----------------------------------[FE_MK_PRMTN_ACTRSLT_INIT] ------------------------------------------------------

TRUNCATE TABLE FE_MK_PRMTN_ACTRSLT_INIT2 ;


INSERT /*+ APPEND PARALLEL(T 4) */
  INTO FE_MK_PRMTN_ACTRSLT_INIT2 T
SELECT /*+ ORDERED USE_HASH(T1 T2 T3 T5 T4) PARALLEL(4) */
       T1.STD_DT                                                          /* ��������               */
     , T1.PRMTNCD                                                         /* ����ڵ�               */
     , T1.INTG_MEMB_NO                                                    /* ����ȸ����ȣ           */
     , NVL(T1.LANG_CD                  ,'z')  AS LANG_CD                  /* ����ڵ�               */
     , NVL(T1.DVIC_CD                  ,'z')  AS DVIC_CD                  /* ����̽��ڵ�           */
     , MAX(T1.CUST_DISTING_NO)                AS CUST_DISTING_NO          /* �����ĺ���ȣ           */
     , MAX(CASE WHEN T1.INTG_MEMB_NO IS NOT NULL THEN 'Y' ELSE 'N' END) AS INTG_MEMB_YN /*����ȸ������ */
     , MAX(T1.INTG_CUST_DISTING_NO)           AS INTG_CUST_DISTING_NO     /* ���հ����ĺ���ȣ       */
     , MAX(NVL(T1.NATLT_CD             ,'z')) AS NATLT_CD                 /* �����ڵ�               */
    /* , MAX(NVL(T99.RNKH_NATLT_CD,'z'))        AS RNKH_NATLT_CD        */    /*���������ڵ�*/
     , MAX(CASE WHEN T1.ORD_MBSSYS_DVS_CD = '04' THEN 'N' ELSE 'Y' END) AS MEMB_YN  /* ȸ������     */
     , MAX(T1.ONLN_MEMB_NO)                   AS ONLN_MEMB_NO
     , MAX(NVL(T1.INTG_MEMB_GRD_CD     ,'z')) AS INTG_MEMB_GRD_CD         /* ����ȸ������ڵ�       */
     , MAX(NVL(T1.IMGN_INFO_DVS_CD     ,'z')) AS IMGN_INFO_DVS_CD         /* ���Ա����������ڵ� 1:�ⱹ */
     , MAX(T1.IMGN_DT                       ) AS IMGN_DT                  /* ���Ա�����             */
     , MAX(NVL(T9.LGPRCD               ,'z')) AS LGPRCD                   /* ������ڵ�             */
     , MAX(NVL(T9.MDPRCD               ,'z')) AS MDPRCD                   /* ������ڵ�             */
     , MAX(NVL(T9.PRMTN_LGCSF_CD       ,'z')) AS PRMTN_LGCSF_CD           /* ����з��ڵ�         */
     , MAX(NVL(T9.PRMTN_MDCSF_CD       ,'z')) AS PRMTN_MDCSF_CD           /* ����ߺз��ڵ�         */
     , SUM(NVL(T2.DLR_PDCST_SUM_AMT      ,0)) AS DLR_PDCST_SUM_AMT        /* �޷������հ�ݾ�       */
     , SUM(NVL(T2.WON_PDCST_SUM_AMT      ,0)) AS WON_PDCST_SUM_AMT        /* ��ȭ�����հ�ݾ�       */
     , SUM(NVL(T2.DLR_NSALAMT            ,0)) AS DLR_NSALAMT              /* �޷��������           */
     , SUM(NVL(T2.WON_NSALAMT            ,0)) AS WON_NSALAMT              /* ��ȭ�������           */
     , SUM(NVL(T2.DLR_PRMTN_NSALAMT      ,0)) AS DLR_PRMTN_NSALAMT        /* �޷����������       */
     , SUM(NVL(T2.WON_PRMTN_NSALAMT      ,0)) AS WON_PRMTN_NSALAMT        /* ��ȭ���������       */
     , SUM(NVL(T3.DC_CNT                 ,0)) AS DC_CNT                   /* ���ΰǼ�               */
     , SUM(NVL(T3.DLR_PRMTN_DC_AMT       ,0)) AS DLR_PRMTN_DC_AMT         /* �޷�������αݾ�       */
     , SUM(NVL(T3.WON_PRMTN_DC_AMT       ,0)) AS WON_PRMTN_DC_AMT         /* ��ȭ������αݾ�       */
     , SUM(NVL(T3.DC_OURCOM_BDN_AMT      ,0)) AS DC_OURCOM_BDN_AMT        /* ���δ��δ�ݾ�       */
     , SUM(NVL(T3.DC_ALYCO_BDN_AMT       ,0)) AS DC_ALYCO_BDN_AMT         /* �������޻�δ�ݾ�     */
     , SUM(NVL(T5.ACMLTMN_OFFR_CNT       ,0)) AS ACMLTMN_OFFR_CNT         /* �����������Ǽ�         */
     , SUM(NVL(T5.DLR_ACMLTMN_OFFR_AMT   ,0)) AS DLR_ACMLTMN_OFFR_AMT     /* �޷������������ݾ�     */
     , SUM(NVL(T5.WON_ACMLTMN_OFFR_AMT   ,0)) AS WON_ACMLTMN_OFFR_AMT     /* ��ȭ�����������ݾ�     */
     , SUM(NVL(T4.ACMLTMN_USE_CNT        ,0)) AS ACMLTMN_USE_CNT          /* �����ݻ��Ǽ�         */
     , SUM(NVL(T4.DLR_ACMLTMN_USE_AMT    ,0)) AS DLR_ACMLTMN_PYF_AMT      /* �޷������ݰ����ݾ�     */
     , SUM(NVL(T4.WON_ACMLTMN_USE_AMT    ,0)) AS WON_ACMLTMN_PYF_AMT      /* ��ȭ�����ݰ����ݾ�     */
     , SUM(NVL(T4.ACMLTMN_OURCOM_BDN_AMT ,0)) AS ACMLTMN_OURCOM_BDN_AMT   /* �����ݴ��δ�ݾ�     */
     , SUM(NVL(T4.ACMLTMN_ALYCO_BDN_AMT  ,0)) AS ACMLTMN_ALYCO_BDN_AMT    /* ���������޻�δ�ݾ�   */
     , SUM(NVL(T2.DLR_ACMLTMN_USE_NSALAMT,0) + NVL(T2.DLR_ACMLTMN_ARSE_NSALAMT,0)) AS DLR_ACMLTMN_USE_NSALAMT  /* �޷������ݻ��������  */
     , SUM(NVL(T2.WON_ACMLTMN_USE_NSALAMT,0) + NVL(T2.WON_ACMLTMN_ARSE_NSALAMT,0)) AS WON_ACMLTMN_USE_NSALAMT  /* ��ȭ�����ݻ��������  */
     , SUM(NVL(T5.LDFP_ACMLT_CNT         ,0)) AS LDFP_ACMLT_CNT           /* LDFPAY�����Ǽ�         */
     , SUM(NVL(T5.DLR_LDFP_ACMLT_AMT     ,0)) AS DLR_LDFP_ACMLT_AMT       /* �޷�LDFPAY�����ݾ�     */
     , SUM(NVL(T5.WON_LDFP_ACMLT_AMT     ,0)) AS WON_LDFP_ACMLT_AMT       /* ��ȭLDFPAY�����ݾ�     */
     , SUM(NVL(T5.LDFP_OURCOM_BDN_AMT    ,0)) AS LDFP_OURCOM_BDN_AMT      /* LDFPAY���δ�ݾ�     */
     , SUM(NVL(T5.LDFP_ALYCO_BDN_AMT     ,0)) AS LDFP_ALYCO_BDN_AMT       /* LDFPAY���޻�δ�ݾ�   */
     , SUM(NVL(T2.DLR_ACMLTMN_USE_NSALAMT,0) + NVL(T2.DLR_ACMLTMN_ARSE_NSALAMT,0) + NVL(T2.DLR_LDFP_ARSE_NSALAMT,0)) AS DLR_ARSE_NSALAMT  /* �޷����߼������      */
     , SUM(NVL(T2.WON_ACMLTMN_USE_NSALAMT,0) + NVL(T2.WON_ACMLTMN_ARSE_NSALAMT,0) + NVL(T2.WON_LDFP_ARSE_NSALAMT,0)) AS WON_ARSE_NSALAMT  /* ��ȭ���߼������      */
     , SUM(NVL(T2.DLR_LDFP_ARSE_NSALAMT  ,0)) AS DLR_LDFP_ARSE_NSALAMT    /* �޷�LDFPAY���߼������ */
     , SUM(NVL(T2.WON_LDFP_ARSE_NSALAMT  ,0)) AS WON_LDFP_ARSE_NSALAMT    /* ��ȭLDFPAY���߼������ */
     , SUM(NVL(T2.OMNI_DLR_NSALAMT       ,0)) AS OMNI_DLR_NSALAMT         /* �ȴϴ޷��������       */
     , SUM(NVL(T2.OMNI_WON_NSALAMT       ,0)) AS OMNI_WON_NSALAMT         /* �ȴϿ�ȭ�������       */
     , SUM(NVL(T2.OMNI_DLR_EXCH_NSALAMT  ,0)) AS OMNI_DLR_EXCH_NSALAMT    /* �ȴϴ޷���ȯ�Ǽ������ */
     , SUM(NVL(T2.OMNI_WON_EXCH_NSALAMT  ,0)) AS OMNI_WON_EXCH_NSALAMT    /* �ȴϿ�ȭ��ȯ�Ǽ������ */
     , SUM(NVL(T2.DLR_CROS_NSALAMT       ,0)) AS DLR_CROS_NSALAMT         /* �޷������������       */
     , SUM(NVL(T2.WON_CROS_NSALAMT       ,0)) AS WON_CROS_NSALAMT         /* ��ȭ�����������       */
     , SYSDATE                                AS LOAD_DTTM                /* �����Ͻ�               */
     , 0                                      AS DLR_CROS_EXCH_NSALAMT    /* �޷�������ȯ�Ǽ������ */
     , 0                                      AS WON_CROS_EXCH_NSALAMT    /* ��ȭ������ȯ�Ǽ������ */
  FROM
     (
        SELECT /*+ PARALLEL(4) */
               T1.PRMTNCD
             , T1.STD_DT
             , T1.INTG_MEMB_NO
             , T1.LANG_CD
             , T1.DVIC_CD
             , MAX(T1.ONLN_MEMB_NO        ) AS ONLN_MEMB_NO
             , MAX(T1.INTG_CUST_DISTING_NO) AS INTG_CUST_DISTING_NO
             , MAX(T1.CUST_DISTING_NO     ) AS CUST_DISTING_NO
             , MAX(T1.NATLT_CD            ) AS NATLT_CD
             , MAX(T1.ORD_MBSSYS_DVS_CD   ) AS ORD_MBSSYS_DVS_CD
             , MAX(T1.INTG_MEMB_GRD_CD    ) AS INTG_MEMB_GRD_CD
             , MAX(T1.IMGN_INFO_DVS_CD    ) AS IMGN_INFO_DVS_CD  /* ���Ա����������ڵ� 1:�ⱹ */
             , MAX(T1.IMGN_DT             ) AS IMGN_DT           /* ���Ա����� */
          FROM FE_MK_PRMTN_ORD_SL T1  /* FE_MK_����ֹ��Ǹ� */
          --  FROM FE_MK_PRMTN_ORD_SL T1  /* FE_MK_����ֹ��Ǹ� */
           /*-- �������� ��� ----------*/
        -- INNER JOIN FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT T0
        --    ON T0.STD_DT       = T1.STD_DT
        --   AND T0.PRMTNCD      = T1.PRMTNCD
        --   AND T0.INTG_MEMB_NO = T1.INTG_MEMB_NO
         GROUP BY T1.PRMTNCD
                , T1.STD_DT
                , T1.INTG_MEMB_NO
                , T1.LANG_CD
                , T1.DVIC_CD
     ) T1
  LEFT OUTER JOIN (
     /* �ֹ����� */
     SELECT /*+ USE_HASH(T0 T1) PARALLEL(4) */
            T1.PRMTNCD
          , T1.STD_DT
          , T1.INTG_MEMB_NO
          , T1.LANG_CD
          , T1.DVIC_CD
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' THEN T2.DLR_PDCST ELSE 0 END)       AS DLR_PDCST_SUM_AMT
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' THEN T2.WON_PDCST ELSE 0 END)       AS WON_PDCST_SUM_AMT
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' THEN T1.DLR_TOT_NSALAMT ELSE 0 END) AS DLR_NSALAMT
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' THEN T1.WON_TOT_NSALAMT ELSE 0 END) AS WON_NSALAMT
          , SUM(T1.DLR_TOT_NSALAMT)                                                       AS DLR_PRMTN_NSALAMT
          , SUM(T1.WON_TOT_NSALAMT)                                                       AS WON_PRMTN_NSALAMT
          , SUM(CASE WHEN T1.OMNI_ORD_YN = 'Y' THEN T1.DLR_TOT_NSALAMT ELSE 0 END)        AS OMNI_DLR_NSALAMT       /* �ȴϴ޷�������� */
          , SUM(CASE WHEN T1.OMNI_ORD_YN = 'Y' THEN T1.WON_TOT_NSALAMT ELSE 0 END)        AS OMNI_WON_NSALAMT       /* �ȴϿ�ȭ������� */
          , SUM(CASE WHEN T1.OMNI_ORD_YN = 'Y' AND T1.EXCH_PRMTN_APLY_YN ='Y' THEN T1.DLR_TOT_NSALAMT ELSE 0 END)       AS OMNI_DLR_EXCH_NSALAMT    /* �ȴϴ޷���ȯ�Ǽ������ */
          , SUM(CASE WHEN T1.OMNI_ORD_YN = 'Y' AND T1.EXCH_PRMTN_APLY_YN ='Y' THEN T1.WON_TOT_NSALAMT ELSE 0 END)       AS OMNI_WON_EXCH_NSALAMT    /* �ȴϿ�ȭ��ȯ�Ǽ������ */
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' AND T1.PRMTN_LGCSF_CD = '007' THEN T1.DLR_TOT_NSALAMT ELSE 0 END) AS DLR_ACMLTMN_USE_NSALAMT
          , SUM(CASE WHEN T1.EXCH_PRMTN_APLY_YN = 'Y' AND T1.PRMTN_LGCSF_CD = '007' THEN T1.WON_TOT_NSALAMT ELSE 0 END) AS WON_ACMLTMN_USE_NSALAMT
          , SUM(T1.DLR_ACMLTMN_ARSE_NSALAMT)                                              AS DLR_ACMLTMN_ARSE_NSALAMT
          , SUM(T1.WON_ACMLTMN_ARSE_NSALAMT)                                              AS WON_ACMLTMN_ARSE_NSALAMT
          , SUM(T1.DLR_LDFP_ARSE_NSALAMT   )                                              AS DLR_LDFP_ARSE_NSALAMT    /* �޷�LDFPAY���߼������ */
          , SUM(T1.WON_LDFP_ARSE_NSALAMT   )                                              AS WON_LDFP_ARSE_NSALAMT    /* ��ȭLDFPAY���߼������ */
          , SUM(T1.DLR_CROS_NSALAMT        )                                              AS DLR_CROS_NSALAMT         /* �޷������������       */
          , SUM(T1.WON_CROS_NSALAMT        )                                              AS WON_CROS_NSALAMT         /* ��ȭ�����������       */
       FROM FE_MK_PRMTN_ORD_SL T1 /* FE_MK_����ֹ��Ǹ� */
    --     FROM FE_MK_PRMTN_ORD_SL T1 /* FE_MK_����ֹ��Ǹ� */
        /*-- �������� ��� ------------------*/
    --  INNER JOIN FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT T0
    --     ON T0.STD_DT       = T1.STD_DT
    --    AND T0.PRMTNCD      = T1.PRMTNCD
    --    AND T0.INTG_MEMB_NO = T1.INTG_MEMB_NO
        ---------------------------------------
       LEFT OUTER JOIN
          (
            SELECT /*+ PARALLEL(4) */
                   T1.STD_DT
                 , T1.ONLN_ORD_NO
                 , T1.PRMTNCD
                 , T3.DLR_PDCST
                 , T3.WON_PDCST
              FROM FE_MK_PRMTN_ORD_SL  T1         /* FE_MK_����ֹ��Ǹ� */
              -- FROM FE_MK_PRMTN_ORD_SL T1         /* FE_MK_����ֹ��Ǹ� */
             INNER JOIN (
                   SELECT /*+ PARALLEL(4) */
                          T2.ONLN_ORD_NO
                        , T2.STD_DT
                        , SUM(T4.DLR_PDCST*T2.SALES_SIGN*T2.ORD_QTY) AS DLR_PDCST
                        , SUM(T4.WON_PDCST*T2.SALES_SIGN*T2.ORD_QTY) AS WON_PDCST
                     FROM FE_SL_ORD_PROD T2  /* FE_SL_�ֹ���ǰ */
                    INNER JOIN WL_IO_DD_PRICE T4  /* WL_�ϼ��Ұ��� */
                       ON T2.STD_DT       = T4.RCPDSBS_DT
                      AND T2.PRDCD        = T4.PRDCD
                      AND T2.STR_CD       = T4.STR_CD
                    GROUP BY T2.ONLN_ORD_NO
                        , T2.STD_DT
                 )  T3
                ON T1.ONLN_ORD_NO  = T3.ONLN_ORD_NO
               AND T1.STD_DT       = T3.STD_DT
             WHERE T1.DLR_TOT_NSALAMT > 0
          ) T2
         ON T1.ONLN_ORD_NO = T2.ONLN_ORD_NO
        AND T1.STD_DT      = T2.STD_DT
        AND T1.PRMTNCD     = T2.PRMTNCD
      GROUP BY T1.PRMTNCD
             , T1.STD_DT
             , T1.INTG_MEMB_NO
             , T1.LANG_CD
             , T1.DVIC_CD
     ) T2
   ON T1.PRMTNCD      = T2.PRMTNCD
  AND T1.STD_DT       = T2.STD_DT
  AND T1.INTG_MEMB_NO = T2.INTG_MEMB_NO
  AND T1.LANG_CD      = T2.LANG_CD
  AND T1.DVIC_CD      = T2.DVIC_CD
  LEFT OUTER JOIN
     ( /* ���αݾ� */
        SELECT /*+ USE_HASH(T1) PARALLEL(4) */
              T1.PRMTNCD
            , T1.STD_DT
            , T1.INTG_MEMB_NO
            , T1.LANG_CD
            , T1.DVIC_CD
            , SUM(NVL(T4.OURCOM_BDNRT,100)/100.0*T3.WON_DC_AMT)          AS DC_OURCOM_BDN_AMT
            , SUM((100.0-NVL(T4.OURCOM_BDNRT,100))/100.0*T3.WON_DC_AMT)  AS DC_ALYCO_BDN_AMT
            , SUM(T3.DLR_DC_AMT)                                         AS DLR_PRMTN_DC_AMT   /* �޷����αݾ� */
            , SUM(T3.WON_DC_AMT)                                         AS WON_PRMTN_DC_AMT   /* ��ȭ���αݾ� */
            , SUM(T3.DC_CNT)                                             AS DC_CNT             /* ���ΰǼ�     */
         FROM FE_MK_PRMTN_ORD_SL T1 /* FE_MK_����ֹ��Ǹ� */
         /*-- �������� ��� --------------------*/
       -- INNER JOIN FE_MK_ONLN_PRMTN_CHNG_TEMP T0
       --    ON T0.STD_DT       = T1.STD_DT
       --   AND T0.PRMTNCD      = T1.PRMTNCD
       --   AND T0.INTG_MEMB_NO = T1.INTG_MEMB_NO
          ---------------------------------------
        INNER JOIN (
              SELECT /*+ USE_HASH(T1 T6 T3 T4) PARALLEL(4) */
                    T2.ORD_DT     AS STD_DT
                  , NVL(T4.PRMTNCD, CAST(T3.EVT_NO AS VARCHAR(10))) AS PRMTNCD
                  , T1.ORD_NO              AS ONLN_ORD_NO
                  , T6.INTG_MEMB_NO        AS INTG_MEMB_NO
                  , SUM(NVL(T1.LCL_DSCNT_AMT,0)*DECODE(T1.ORD_DSCNT_STAT_CD,'01',1,'02',-1,0))  AS WON_DC_AMT
                  , SUM(NVL(T1.GLBL_DSCNT_AMT,0)*DECODE(T1.ORD_DSCNT_STAT_CD,'01',1,'02',-1,0)) AS DLR_DC_AMT
                  , SUM(DECODE(T1.ORD_DSCNT_STAT_CD,'01',1,'02',-1,0)) AS DC_CNT
               FROM WE_OD_ORD_DSCNT  T1   /* WE_�ֹ����� */
              INNER JOIN WE_OD_ORD   T2   /* WE_�ֹ� */
                 ON T1.ORD_NO            = T2.ORD_NO
                AND T1.ORD_DSCNT_KND_CD IN ('01','03') /* 01 ���� 02 ���� 03 ���� */
          --    INNER JOIN (  --�������縦 ���� temp
          --          SELECT ONLN_ORD_NO
          --               , STD_DT
          --            FROM FE_MK_PRMTN_ORD_TEMP_INIT2
          --           GROUP BY ONLN_ORD_NO
          --               , STD_DT
          --          ) T0
          --       ON T1.ORD_NO = T0.ONLN_ORD_NO
          --      AND T2.ORD_DT = T0.STD_DT
               LEFT OUTER JOIN WE_MT_EVT_FVR T3  /* WE_������� */
                 ON T1.ORD_DSCNT_REF_NO  = T3.EVT_FVR_NO
               LEFT OUTER JOIN ( /* ����� */
                   SELECT DISTINCT T1.DEAL_EVT_FVR_NO
                        , T2.DEAL_EVT_NO
                        , CAST(T2.EVT_NO AS VARCHAR(10)) AS PRMTNCD
                     FROM WE_MT_DEAL_EVT_FVR  T1  /* WE_��������� */
                    INNER JOIN WE_MT_DEAL_EVT T2  /* WE_����� */
                       ON T1.DEAL_EVT_NO =  T2.DEAL_EVT_NO
                      AND T2.EVT_NO IS NOT NULL
                   ) T4
                 ON T1.ORD_DSCNT_REF_NO  = T4.DEAL_EVT_FVR_NO
               LEFT OUTER JOIN DE_ONLN_MEMB T6  /* DE_�¶���ȸ�� */
                 ON T2.MBR_NO            = T6.ONLN_MEMB_NO
              WHERE T1.ORD_DSCNT_STAT_CD IN ('01','02')
              GROUP BY  T2.ORD_DT
                  , NVL(T4.PRMTNCD, CAST(T3.EVT_NO AS VARCHAR(10)))
                  , T1.ORD_NO
                  , T6.INTG_MEMB_NO
            ) T3
           ON T1.STD_DT         = T3.STD_DT
          AND T1.ONLN_ORD_NO    = T3.ONLN_ORD_NO
          AND T1.PRMTNCD        = T3.PRMTNCD
          AND T1.INTG_MEMB_NO   = T3.INTG_MEMB_NO
        INNER JOIN D_PRMTN T4
           ON T1.PRMTNCD        = T4.PRMTNCD
        WHERE T1.PRMTN_LGCSF_CD IN ('001','014')  /* ���� �� */
        GROUP BY T1.PRMTNCD
               , T1.STD_DT
               , T1.INTG_MEMB_NO
               , T1.LANG_CD
               , T1.DVIC_CD

     ) T3
   ON T1.PRMTNCD      = T3.PRMTNCD
  AND T1.STD_DT       = T3.STD_DT
  AND T1.INTG_MEMB_NO = T3.INTG_MEMB_NO
  AND T1.LANG_CD      = T3.LANG_CD
  AND T1.DVIC_CD      = T3.DVIC_CD
 LEFT OUTER JOIN (
      /* LDFPAY����, ������������ ���� */
      SELECT /*+ USE_HASH(T1 T0) PARALLEL(4) */
            T1.STD_DT
          , T1.PRMTNCD
          , T1.INTG_MEMB_NO
          , T1.LANG_CD
          , MAX(T1.DVIC_CD)  AS DVIC_CD
          , 0       AS ACMLTMN_OFFR_CNT     -- SUM(CASE WHEN T1.PRMTN_LGCSF_CD = '007' THEN T1.OFFER_PRESTAT_CNT ELSE 0 END)     AS ACMLTMN_OFFR_CNT
          , 0       AS DLR_ACMLTMN_OFFR_AMT -- SUM(CASE WHEN T1.PRMTN_LGCSF_CD = '007' THEN T1.DLR_OFFER_PRESTAT_AMT ELSE 0 END) AS DLR_ACMLTMN_OFFR_AMT
          , 0       AS WON_ACMLTMN_OFFR_AMT -- SUM(CASE WHEN T1.PRMTN_LGCSF_CD = '007' THEN T1.WON_OFFER_PRESTAT_AMT ELSE 0 END) AS WON_ACMLTMN_OFFR_AMT
          , SUM(T1.OFFER_PRESTAT_CNT    )        AS LDFP_ACMLT_CNT
          , SUM(T1.DLR_OFFER_PRESTAT_AMT)        AS DLR_LDFP_ACMLT_AMT
          , SUM(T1.WON_OFFER_PRESTAT_AMT)        AS WON_LDFP_ACMLT_AMT
          , SUM(T1.OFFER_PRESTAT_OURCOM_BDN_AMT) AS LDFP_OURCOM_BDN_AMT
          , SUM(T1.WON_OFFER_PRESTAT_AMT-T1.OFFER_PRESTAT_OURCOM_BDN_AMT) AS LDFP_ALYCO_BDN_AMT
       FROM FE_MK_BNFT_OFFER_DTL T1  /* FE_MK_����OFFER�� */
        /*-- �������� ��� --------------------*/
      INNER JOIN FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT2 T0
         ON T0.STD_DT             = T1.STD_DT
        AND T0.PRMTNCD            = T1.PRMTNCD
        AND T0.INTG_MEMB_NO       = T1.INTG_MEMB_NO
        AND T1.STD_DT       BETWEEN T0.PRMTN_STRT_DT AND T0.PRMTN_END_DT
      WHERE T1.ONLN_OFFER_CLSF_CD  = '07'       /* 07:LDFPAY */
        AND T1.OFFER_PRESTAT_CNT <> 0
      GROUP BY T1.STD_DT
             , T1.PRMTNCD
             , T1.INTG_MEMB_NO
             , T1.LANG_CD
        --     , T1.DVIC_CD
     ) T5
    ON T1.PRMTNCD      = T5.PRMTNCD
   AND T1.STD_DT       = T5.STD_DT
   AND T1.INTG_MEMB_NO = T5.INTG_MEMB_NO
   AND T1.LANG_CD      = T5.LANG_CD
  --  AND T1.DVIC_CD      = T5.DVIC_CD
  LEFT OUTER JOIN (
       /* �����ݻ�� */
      SELECT /*+ USE_HASH(T1 T0) PARALLEL(4) */
            T1.STD_DT
          , T1.PRMTNCD
          , T1.INTG_MEMB_NO
          , T1.LANG_CD
          , T1.DVIC_CD
          , SUM(T1.OFFER_USE_CNT    )        AS ACMLTMN_USE_CNT
          , SUM(T1.DLR_OFFER_USE_AMT)        AS DLR_ACMLTMN_USE_AMT
          , SUM(T1.WON_OFFER_USE_AMT)        AS WON_ACMLTMN_USE_AMT
          , SUM(T1.OFFER_USE_OURCOM_BDN_AMT) AS ACMLTMN_OURCOM_BDN_AMT
          , SUM(T1.WON_OFFER_USE_AMT)-SUM(T1.OFFER_USE_OURCOM_BDN_AMT) AS ACMLTMN_ALYCO_BDN_AMT
       FROM FE_MK_BNFT_OFFER_DTL T1  /* FE_MK_����OFFER�� */
        /*-- �������� ��� --------------------*/
      INNER JOIN FE_MK_ONLN_PRMTN_CHNG_TEMP_INIT2 T0
         ON T0.STD_DT             = T1.STD_DT
        AND T0.PRMTNCD            = T1.PRMTNCD
        AND T0.INTG_MEMB_NO       = T1.INTG_MEMB_NO
        AND T1.STD_DT       BETWEEN T0.PRMTN_STRT_DT AND T0.PRMTN_END_DT
      WHERE T1.ONLN_OFFER_CLSF_CD ='02'      /* 02:������ */
        AND T1.PRMTN_LGCSF_CD NOT IN ('001','005')       /* �ϳ��� ��簡 ������, LDFPAY�� ���۸� ���°�� �ߺ����ܸ� ���� ��� */
        AND T1.OFFER_USE_CNT <> 0
      GROUP BY T1.STD_DT
             , T1.PRMTNCD
             , T1.INTG_MEMB_NO
             , T1.LANG_CD
             , T1.DVIC_CD
      ) T4
    ON T1.PRMTNCD      = T4.PRMTNCD
   AND T1.STD_DT       = T4.STD_DT
   AND T1.INTG_MEMB_NO = T4.INTG_MEMB_NO
   AND T1.LANG_CD      = T4.LANG_CD
   AND T1.DVIC_CD      = T4.DVIC_CD
 INNER JOIN (
       SELECT T1.PRMTNCD
            , T1.PRMTN_LGCSF_CD
            , T1.PRMTN_MDCSF_CD
            , T1.MDPRCD
            , T1.LGPRCD
         FROM D_PRMTN t1
        WHERE NOT EXISTS (SELECT 1 FROM D_LGPROMO T2 WHERE T1.LGPRCD = T2.LGPRCD AND T2.PRMTN_ACTRSLT_OBJ_XCLUD_YN = 'Y')
     ) T9
    ON T1.PRMTNCD = T9.PRMTNCD
/* INNER JOIN D_PRMTN T9                     */
/*    ON T1.PRMTNCD = T9.PRMTNCD             */
/* INNER JOIN D_LGPROMO T7                   */
/*    ON T9.LGPRCD =  T7.LGPRCD              */
/*   AND T7.PRMTN_ACTRSLT_OBJ_XCLUD_YN = 'N' */ /* ������������ܿ��� */
 GROUP BY T1.STD_DT
        , T1.PRMTNCD
        , T1.INTG_MEMB_NO
        , NVL(T1.LANG_CD ,'z')
        , NVL(T1.DVIC_CD ,'z')
;


-------------------------------------------------------


 SELECT '1', PRMTN_LGCSF_CD, PRMTNCD  , SUM(DLR_PDCST_SUM_AMT) , SUM(WON_PDCST_SUM_AMT) , SUM(DLR_NSALAMT)
 , SUM(WON_NSALAMT             ) , SUM(DLR_PRMTN_NSALAMT       ) , SUM(WON_PRMTN_NSALAMT       )
 , SUM(DC_CNT                  ) , SUM(DLR_PRMTN_DC_AMT        ) , SUM(WON_PRMTN_DC_AMT        )
 , SUM(DC_OURCOM_BDN_AMT       ) , SUM(DC_ALYCO_BDN_AMT        ) , SUM(ACMLTMN_OFFR_CNT        )
 , SUM(DLR_ACMLTMN_OFFR_AMT    ) , SUM(WON_ACMLTMN_OFFR_AMT    ) , SUM(ACMLTMN_USE_CNT         )
 , SUM(DLR_ACMLTMN_PYF_AMT     ) , SUM(WON_ACMLTMN_PYF_AMT     ) , SUM(ACMLTMN_OURCOM_BDN_AMT  )
 , SUM(ACMLTMN_ALYCO_BDN_AMT   ) , SUM(DLR_ACMLTMN_USE_NSALAMT ) , SUM(WON_ACMLTMN_USE_NSALAMT )
 , SUM(LDFP_ACMLT_CNT          ) , SUM(DLR_LDFP_ACMLT_AMT      ) , SUM(WON_LDFP_ACMLT_AMT      )
 , SUM(LDFP_OURCOM_BDN_AMT     ) , SUM(LDFP_ALYCO_BDN_AMT      ) , SUM(DLR_ARSE_NSALAMT        )
 , SUM(WON_ARSE_NSALAMT        ) , SUM(DLR_LDFP_ARSE_NSALAMT   ) , SUM(WON_LDFP_ARSE_NSALAMT   )
 , SUM(OMNI_DLR_NSALAMT        ) , SUM(OMNI_WON_NSALAMT        ) , SUM(OMNI_DLR_EXCH_NSALAMT   )
 , SUM(OMNI_WON_EXCH_NSALAMT   ) , SUM(DLR_CROS_NSALAMT        ) , SUM(WON_CROS_NSALAMT        )
 , SUM(DLR_CROS_EXCH_NSALAMT   ) , SUM(WON_CROS_EXCH_NSALAMT   )
FROM FE_MK_PRMTN_ACTRSLT_INIT
WHERE STD_DT BETWEEN '20231201' AND '20231231'
GROUP BY  PRMTN_LGCSF_CD, PRMTNCD
UNION ALL            
SELECT '2', PRMTN_LGCSF_CD, PRMTNCD  , SUM(DLR_PDCST_SUM_AMT) , SUM(WON_PDCST_SUM_AMT) , SUM(DLR_NSALAMT)
 , SUM(WON_NSALAMT             ) , SUM(DLR_PRMTN_NSALAMT       ) , SUM(WON_PRMTN_NSALAMT       )
 , SUM(DC_CNT                  ) , SUM(DLR_PRMTN_DC_AMT        ) , SUM(WON_PRMTN_DC_AMT        )
 , SUM(DC_OURCOM_BDN_AMT       ) , SUM(DC_ALYCO_BDN_AMT        ) , SUM(ACMLTMN_OFFR_CNT        )
 , SUM(DLR_ACMLTMN_OFFR_AMT    ) , SUM(WON_ACMLTMN_OFFR_AMT    ) , SUM(ACMLTMN_USE_CNT         )
 , SUM(DLR_ACMLTMN_PYF_AMT     ) , SUM(WON_ACMLTMN_PYF_AMT     ) , SUM(ACMLTMN_OURCOM_BDN_AMT  )
 , SUM(ACMLTMN_ALYCO_BDN_AMT   ) , SUM(DLR_ACMLTMN_USE_NSALAMT ) , SUM(WON_ACMLTMN_USE_NSALAMT )
 , SUM(LDFP_ACMLT_CNT          ) , SUM(DLR_LDFP_ACMLT_AMT      ) , SUM(WON_LDFP_ACMLT_AMT      )
 , SUM(LDFP_OURCOM_BDN_AMT     ) , SUM(LDFP_ALYCO_BDN_AMT      ) , SUM(DLR_ARSE_NSALAMT        )
 , SUM(WON_ARSE_NSALAMT        ) , SUM(DLR_LDFP_ARSE_NSALAMT   ) , SUM(WON_LDFP_ARSE_NSALAMT   )
 , SUM(OMNI_DLR_NSALAMT        ) , SUM(OMNI_WON_NSALAMT        ) , SUM(OMNI_DLR_EXCH_NSALAMT   )
 , SUM(OMNI_WON_EXCH_NSALAMT   ) , SUM(DLR_CROS_NSALAMT        ) , SUM(WON_CROS_NSALAMT        )
 , SUM(DLR_CROS_EXCH_NSALAMT   ) , SUM(WON_CROS_EXCH_NSALAMT   )
FROM FE_MK_PRMTN_ACTRSLT_INIT2
WHERE STD_DT BETWEEN '20231201' AND '20231231'
GROUP BY  PRMTN_LGCSF_CD, PRMTNCD
ORDER BY 2,3,1