--1. ��纰
 SELECT M.LGPRCD                              AS LGPRCD                    /* ������ڵ� */
         , M.LGPROMO_NM                          AS LGPROMO_NM                /* ������ */
         , M.MDPRCD                              AS MDPRCD                    /* ������ڵ� */
         , M.MIDPROMO_NM                         AS MIDPROMO_NM               /* ������ */
         , M.PRMTNCD                             AS PRMTNCD                   /* ������ڵ� */
         , M.PRMTN_NM                            AS PRMTN_NM                  /* ������ */
       , CASE WHEN M.CHNL_TYPE_CD = '1' THEN (SELECT REGEXP_REPLACE(LISTAGG(B1.STR_NM, '/' ON OVERFLOW TRUNCATE) WITHIN GROUP(ORDER BY B1.PRMTNCD), '([^/]+)(/\1)*(/|$)', '\1\3' ) AS STR_LANG_NM
                                                  FROM (SELECT B1.PRMTNCD 
                                                             , CD2.STR_NM
                                                          FROM LDF_DW.D_PRMTN B1                     /* D_��� */
                                           , LDF_DW.WL_LC_PRMTN_OFFR_CNDT B2       /* LC_����������� ���̺� */
                                                             , LDF_DW.D_STR CD2                      /* ���� ������ ���̺� */
                                                         WHERE 1                       = 1
                                                           AND B1.LGPRCD               = M.LGPRCD
                                                           AND B1.MDPRCD               = M.MDPRCD 
                                                           AND B2.PRMTNCD              = M.PRMTNCD
                                                           AND B1.PRMTNCD              = B2.PRMTNCD
                                                           AND B2.PRMTN_CNDT_VAL       = CD2.STR_CD
                                                           AND B1.CHNL_TYPE_CD         = '02'          /* ä�� - �������� */
                                                           AND B2.PRMTN_OFFR_CNDT_CD   = '01'          /* ���������ڵ� */
                                                           AND CD2.STR_CD              <> '907'        /* ���� ��õ����B ���� */  
                                                         GROUP BY B1.PRMTNCD 
                                                             , CD2.STR_NM
                                                        ) B1
                                                 ) 
                                          ELSE (SELECT REGEXP_REPLACE(LISTAGG(CD2.CD_DESC, '/' ON OVERFLOW TRUNCATE) WITHIN GROUP(ORDER BY B1.PRMTNCD), '([^/]+)(/\1)*(/|$)', '\1\3') AS STR_LANG_NM
                                                  FROM LDF_DW.D_PRMTN B1                        /* D_��� */
                                         , LDF_DW.WL_LC_PRMTN_OFFR_CNDT B2          /* LC_����������� ���̺� */
                                                     , LDF_DW.WE_ST_COM_CD_DTL CD2              /* �������̺� */
                                                 WHERE 1                       = 1
                                                   AND B1.LGPRCD               = M.LGPRCD
                                                   AND B1.MDPRCD               = M.MDPRCD 
                                                   AND B1.PRMTNCD              = M.PRMTNCD
                                                   AND B1.PRMTNCD              = B2.PRMTNCD
                                                   AND B2.PRMTN_CNDT_VAL       = CD2.COM_CD
                                                   AND B1.CHNL_TYPE_CD         = '01'           /* ä�� - �¶��� */
                                                   AND CD2.COM_GRP_CD          = 'LANG_CD'
                                                   AND B2.PRMTN_OFFR_CNDT_CD   = '01'           /* �����ڵ� */                                                                        
                                               ) 
           END                                    AS STR_LANG_NM               /* ����/��� */
         , M.PRMTN_LGCSF_CD                       AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
         , M.PRMTN_LGCSF_NM                       AS PRMTN_LGCSF_NM            /* ����з��� */
         , M.PRMTN_MDCSF_CD                       AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */
         , M.PRMTN_MDCSF_NM                       AS PRMTN_MDCSF_NM            /* ����з��� */
         , M.PRMTN_STRT_DT                        AS PRMTN_STRT_DT             /* ���������� */
         , M.PRMTN_END_DT                         AS PRMTN_END_DT              /* ����������� */
         , NVL(M.WON_EXCH_NSALAMT,0)              AS WON_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(��ȭ) */
         , NVL(M.DLR_EXCH_NSALAMT,0)              AS DLR_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(�޷�) */
         , NVL(M.EXCH_SALES_CNT,0)                AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
         , NVL(M.WON_ARSE_NSALAMT_CUSTRN,0)       AS WON_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(��ȭ) */
         , NVL(M.DLR_ARSE_NSALAMT_CUSTRN,0)       AS DLR_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(�޷�) */
         , NVL(M.WON_PRMTN_NSALAMT,0)             AS WON_PRMTN_NSALAMT         /* ������_����(��ȭ) */
         , NVL(M.DLR_PRMTN_NSALAMT,0)             AS DLR_PRMTN_NSALAMT         /* ������_����(�޷�) */
         , NVL(M.PRMTN_NSALAMT_CNT,0)             AS PRMTN_NSALAMT_CNT         /* ������_�������� */
         , NVL(M.WON_PRMTN_NSALAMT_CUSTRN,0)      AS WON_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(��ȭ) */
         , NVL(M.DLR_PRMTN_NSALAMT_CUSTRN,0)      AS DLR_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(�޷�) */
         , NVL(M.WON_LDFP_ACMLT_AMT,0)            AS WON_LDFP_ACMLT_AMT        /* LDFPAY_�����ݾ�(��ȭ) */
         , NVL(M.LDFP_ACMLT_CNT,0)                AS LDFP_ACMLT_CNT            /* LDFPAY_�����Ǽ� */
         , NVL(M.LDFP_ACMLT_CUST_NBR,0)           AS LDFP_ACMLT_CUST_NBR       /* LDFPAY_�������� */
         , NVL(M.FREELDFP_USE_AMT,0)              AS FREELDFP_USE_AMT          /* FREE_LDFPAY_���ݾ� */
         , NVL(M.FREELDFP_USE_CNT,0)              AS FREELDFP_USE_CNT          /* FREE_LDFPAY_���Ǽ� */
         , NVL(M.FREELDFP_USE_CUST_NBR,0)         AS FREELDFP_USE_CUST_NBR     /* FREE_LDFPAY_��밴�� */
         , NVL(M.FREELDFP_ACMLT_AMT,0)            AS FREELDFP_ACMLT_AMT          /* FREE_LDFPAY_�����ݾ� */
         , NVL(M.FREELDFP_ACMLT_CNT,0)            AS FREELDFP_ACMLT_CNT          /* FREE_LDFPAY_�����Ǽ� */
         , NVL(M.FREELDFP_ACLMLT_CUST_NBR,0)      AS FREELDFP_ACLMLT_CUST_NBR     /* FREE_LDFPAY_�������� */
         , NVL(M.DC_AMT,0)                        AS DC_AMT                    /* ����_�ݾ� */
         , NVL(M.DC_CNT,0)                        AS DC_CNT                    /* ����_�Ǽ� */
         , NVL(M.BDN_CUST_NBR,0)                  AS BDN_CUST_NBR              /* ����_���� */
         , NVL(M.FGF_PRESTAT_AMT,0)               AS FGF_PRESTAT_AMT           /* ����ǰ����_�ݾ� */
         , NVL(M.FGF_PRESTAT_CNT,0)               AS FGF_PRESTAT_CNT           /* ����ǰ����_�Ǽ� */
         , NVL(M.FGF_PRESTAT_CUST_NBR,0)          AS FGF_PRESTAT_CUST_NBR      /* ����ǰ����_���� */
         , NVL(M.ACMLTMN_OFFR_CNT,0)              AS ACMLTMN_OFFR_CNT          /* ����������_�Ǽ� */
         , NVL(M.DLR_ACMLTMN_OFFR_AMT,0)          AS DLR_ACMLTMN_OFFR_AMT      /* ����������_�ݾ�(��ȭ) */
         , NVL(M.ACMLTMN_OFFR_CUST_NBR,0)         AS ACMLTMN_OFFR_CUST_NBR     /* ����������_���� */
         , NVL(M.ACMLTMN_USE_CNT,0)               AS ACMLTMN_USE_CNT           /* �����ݻ��_�Ǽ� */
         , NVL(M.WON_ACMLTMN_PYF_AMT,0)           AS WON_ACMLTMN_PYF_AMT       /* �����ݻ��_�ݾ�(��ȭ) */
         , NVL(M.ACMLTMN_USE_CUST_NBR,0)          AS ACMLTMN_USE_CUST_NBR      /* �����ݻ��_���� */
         , NVL(M.TOT_PRESTAT_AMT,0)               AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü) */
         , NVL(M.PRESTAT_OURCOM_BDN_AMT,0)        AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���) */
         , NVL(M.PRESTAT_ALYCO_BDN_AMT,0)         AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�) */
         , NVL(M.DC_TOT_PRESTAT_RATE,0)           AS OURCOM_PRESTAT_RATE       /* ������(��ü) */   
         , NVL(M.OURCOM_PRESTAT_RATE,0)           AS DC_TOT_PRESTAT_RATE       /* ������(���) */     
         , NVL(M.TOT_BDN_AMT,0)                   AS TOT_BDN_AMT               /* ���αݾ�(��ü) */
         , NVL(M.DC_OURCOM_BDN_AMT,0)             AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
         , NVL(M.DC_ALYCO_BDN_AMT,0)              AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */
         , NVL(M.TOT_DC_CNT,0)                    AS TOT_DC_CNT                /* ���ΰǼ� */
         , NVL(M.WON_TOT_DC_AMT,0)                AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ� */
         , NVL(M.DC_TOT_BDN_RATE,0)               AS DC_OURCOM_BDN_RATE           /* ������(��ü) */
         , NVL(M.DC_OURCOM_BDN_RATE,0)            AS DC_TOT_BDN_RATE        /* ������(���) */  
         , NVL(M.TOT_PRESTAT_AMT+M.TOT_BDN_AMT,0) AS PRMTN_EXP                 /* �����(�����ݾ�+���αݾ�) */
         , NVL(ROUND(((M.TOT_PRESTAT_AMT + M.TOT_BDN_AMT) / DECODE(M.WON_PRMTN_NSALAMT, 0, NULL, M.WON_PRMTN_NSALAMT))*100,1),0) AS INTG_SUPTRT   /* ����������(�����ݾ�+���αݾ�) / ��ȭ��������� */ 
         , NVL(M.WON_ARSE_NSALAMT,0)              AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ) */
         , NVL(M.ONLN_WON_ARSE_NSALAMT,0)         AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸���(��ȭ) */
         , NVL(M.ONLN_DLR_ARSE_NSALAMT,0)         AS ONLN_DLR_ARSE_NSALAMT     /* �¶������߸���(�޷�) */
         , NVL(M.OFLN_WON_ARSE_NSALAMT,0)         AS OFLN_WON_ARSE_NSALAMT     /* �����������߸���(��ȭ) */
         , NVL(M.OFLN_DLR_ARSE_NSALAMT,0)         AS OFLN_DLR_ARSE_NSALAMT     /* �����������߸���(�޷�) */
         , NVL(M.OMNI_WON_EXCH_NSALAMT,0)         AS OMNI_WON_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(��ȭ) */
         , NVL(M.OMNI_DLR_EXCH_NSALAMT,0)         AS OMNI_DLR_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(�޷�) */
         , NVL(M.OMNI_WON_NSALAMT,0)              AS OMNI_WON_NSALAMT          /* ���ȴϸ���(��ȭ) */
         , NVL(M.OMNI_DLR_NSALAMT,0)              AS OMNI_DLR_NSALAMT          /* ���ȴϸ���(�޷�) */
         , M.RGSTPSN_ID                           AS RGSTPSN_ID                /* �����ID */
         , M.USR_NM                               AS RGSTPSN_NM                /* ����ڸ� */
         , M.RGST_DEPTCD                          AS RGST_DEPTCD               /* ��Ϻμ��ڵ� */
         , M.DEPT_NM                              AS RGST_DEPT_NM              /* ��Ϻμ��� */
      FROM (SELECT T.LGPRCD                                                                                                                                                                                    AS LGPRCD
                  , T.LGPROMO_NM                                                                                                                                                                               AS LGPROMO_NM
                  , T.MDPRCD                                                                                                                                                                                   AS MDPRCD
                  , T.MIDPROMO_NM                                                                                                                                                                              AS MIDPROMO_NM
                  , T.PRMTNCD                                                                                                                                                                                  AS PRMTNCD
                  , T.PRMTN_NM                                                                                                                                                                                 AS PRMTN_NM
                  , MAX(T.CHNL_TYPE_CD)                                                                                                                                                                        AS CHNL_TYPE_CD                  /* ����/��� ���� ��(���) */
                  , MAX(T.PRMTN_LGCSF_CD)                                                                                                                                                                      AS PRMTN_LGCSF_CD
                  , MAX(T.PRMTN_LGCSF_NM)                                                                                                                                                                      AS PRMTN_LGCSF_NM
                  , MAX(T.PRMTN_MDCSF_CD)                                                                                                                                                                      AS PRMTN_MDCSF_CD
                  , MAX(T.PRMTN_MDCSF_NM)                                                                                                                                                                      AS PRMTN_MDCSF_NM
                  , MAX(T.PRMTN_STRT_DT)                                                                                                                                                                       AS PRMTN_STRT_DT
                  , MAX(T.PRMTN_END_DT)                                                                                                                                                                        AS PRMTN_END_DT
                  , SUM(T.WON_EXCH_NSALAMT)                                                                                                                                                                    AS WON_EXCH_NSALAMT
              , SUM(T.DLR_EXCH_NSALAMT)                                                                                                                                                                    AS DLR_EXCH_NSALAMT
              , COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0    THEN T.EXCH_SALES_CNT  END)                                                                                                 AS EXCH_SALES_CNT        
              , ROUND(NVL(SUM(T.WON_EXCH_NSALAMT)   
                / DECODE(COUNT(DISTINCT CASE WHEN T.WON_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.WON_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END)),0))        AS WON_ARSE_NSALAMT_CUSTRN
              , ROUND(NVL(SUM(T.DLR_EXCH_NSALAMT)   
                / DECODE(COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END)),0))        AS DLR_ARSE_NSALAMT_CUSTRN           
              , SUM(T.WON_PRMTN_NSALAMT)                                                                                                                                                                   AS WON_PRMTN_NSALAMT
              , SUM(T.DLR_PRMTN_NSALAMT)                                                                                                                                                                   AS DLR_PRMTN_NSALAMT
              , COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0   THEN T.PRMTN_NSALAMT_CNT END)                                                                                               AS PRMTN_NSALAMT_CNT
              , ROUND(NVL(SUM(T.WON_PRMTN_NSALAMT)  
                / DECODE(COUNT(DISTINCT CASE WHEN T.WON_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.WON_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END)),0))  AS WON_PRMTN_NSALAMT_CUSTRN
              , ROUND(NVL(SUM(T.DLR_PRMTN_NSALAMT)  
                / DECODE(COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END)),0))  AS DLR_PRMTN_NSALAMT_CUSTRN
              , SUM(T.WON_LDFP_ACMLT_AMT)                                                                                                                                                                  AS WON_LDFP_ACMLT_AMT
              , SUM(T.LDFP_ACMLT_CNT)                                                                                                                                                                      AS LDFP_ACMLT_CNT
              , COUNT(DISTINCT CASE WHEN T.WON_LDFP_ACMLT_AMT IS NOT NULL AND T.WON_LDFP_ACMLT_AMT <> 0  THEN T.INTG_MEMB_NO END)                                                                          AS LDFP_ACMLT_CUST_NBR
              , SUM(T.FREELDFP_USE_AMT)                                                                                                                                                                    AS FREELDFP_USE_AMT
              , SUM(T.FREELDFP_USE_CNT)                                                                                                                                                                    AS FREELDFP_USE_CNT
              , COUNT(DISTINCT CASE WHEN T.FREELDFP_USE_AMT   IS NOT NULL AND T.FREELDFP_USE_AMT <> 0    THEN T.INTG_MEMB_NO END)                                                                          AS FREELDFP_USE_CUST_NBR
                  , SUM(T.FREELDFP_ACMLT_AMT)                                                                                                                                                                  AS FREELDFP_ACMLT_AMT          /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                  , SUM(T.FREELDFP_ACMLT_CNT)                                                                                                                                                                  AS FREELDFP_ACMLT_CNT          /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
              , COUNT(DISTINCT CASE WHEN T.FREELDFP_ACMLT_AMT IS NOT NULL AND T.FREELDFP_ACMLT_AMT <> 0  THEN T.INTG_MEMB_NO END)                                                                          AS FREELDFP_ACLMLT_CUST_NBR
              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS DC_AMT
              , SUM(T.DC_CNT)                                                                                                                                                                              AS DC_CNT
              , COUNT(DISTINCT CASE WHEN T.WON_TOT_DC_AMT     IS NOT NULL AND T.WON_TOT_DC_AMT <> 0      THEN T.INTG_MEMB_NO END)                                                                          AS BDN_CUST_NBR
              , SUM(T.FGF_PRESTAT_AMT)                                                                                                                                                                     AS FGF_PRESTAT_AMT
              , SUM(T.FGF_PRESTAT_CNT)                                                                                                                                                                     AS FGF_PRESTAT_CNT
              , COUNT(DISTINCT CASE WHEN T.FGF_PRESTAT_AMT    IS NOT NULL AND T.FGF_PRESTAT_AMT <> 0     THEN T.INTG_MEMB_NO END)                                                                          AS FGF_PRESTAT_CUST_NBR
                  , MAX(T.ACMLTMN_OFFR_CUST)                                                                                                                                                                   AS ACMLTMN_OFFR_CUST_NBR     /* �����������Ǽ� */
                  , MAX(T.ACMLTMN_OFFR_CNT)                                                                                                                                                                    AS ACMLTMN_OFFR_CNT          /* ����������_�Ǽ� */
                  , MAX(T.DLR_ACMLTMN_OFFR_AMT)                                                                                                                                                                AS DLR_ACMLTMN_OFFR_AMT      /* ����������_�Ǽ� */ 
              , SUM(T.ACMLTMN_USE_CNT)                                                                                                                                                                     AS ACMLTMN_USE_CNT
              , SUM(T.WON_ACMLTMN_PYF_AMT)                                                                                                                                                                 AS WON_ACMLTMN_PYF_AMT
              , COUNT(DISTINCT CASE WHEN T.WON_ACMLTMN_PYF_AMT IS NOT NULL AND T.WON_ACMLTMN_PYF_AMT <> 0 THEN T.INTG_MEMB_NO END)                                                                         AS ACMLTMN_USE_CUST_NBR
              , SUM(T.TOT_PRESTAT_AMT)                                                                                                                                                                     AS TOT_PRESTAT_AMT
              , SUM(T.PRESTAT_OURCOM_BDN_AMT)                                                                                                                                                              AS PRESTAT_OURCOM_BDN_AMT
              , SUM(T.PRESTAT_ALYCO_BDN_AMT)                                                                                                                                                               AS PRESTAT_ALYCO_BDN_AMT
                  , ROUND(NVL(SUM(T.TOT_PRESTAT_AMT) / DECODE(SUM(T.WON_EXCH_NSALAMT),0,NULL,SUM(T.WON_EXCH_NSALAMT)),0) * 100,1)                                                                               AS DC_TOT_PRESTAT_RATE /* ������(��ü) - ADD */
                  , ROUND(NVL(SUM(T.PRESTAT_OURCOM_BDN_AMT) / DECODE(SUM(T.WON_EXCH_NSALAMT),0,NULL,SUM(T.WON_EXCH_NSALAMT)),0) * 100,1)                                                                       AS OURCOM_PRESTAT_RATE /* ������(���) */
              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS TOT_BDN_AMT
              , SUM(T.DC_OURCOM_BDN_AMT)                                                                                                                                                                   AS DC_OURCOM_BDN_AMT
              , SUM(T.DC_ALYCO_BDN_AMT)                                                                                                                                                                    AS DC_ALYCO_BDN_AMT
              , SUM(T.DC_CNT)                                                                                                                                                                              AS TOT_DC_CNT
              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS WON_TOT_DC_AMT
                  , ROUND(NVL(SUM(T.WON_TOT_DC_AMT)     / DECODE(SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT),0,NULL,SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT)),0) * 100,1)                           AS DC_TOT_BDN_RATE /* ������(��ü) */
                  , ROUND(NVL(SUM(T.DC_OURCOM_BDN_AMT)     / DECODE(SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT),0,NULL,SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT)),0) * 100,1)                        AS DC_OURCOM_BDN_RATE /* ������(���) */
              , SUM(T.WON_ARSE_NSALAMT)                                                                                                                                                                    AS WON_ARSE_NSALAMT
              , SUM(T.DLR_ARSE_NSALAMT)                                                                                                                                                                    AS DLR_ARSE_NSALAMT
              , SUM(T.ONLN_WON_ARSE_NSALAMT)                                                                                                                                                               AS ONLN_WON_ARSE_NSALAMT
              , SUM(T.ONLN_DLR_ARSE_NSALAMT)                                                                                                                                                               AS ONLN_DLR_ARSE_NSALAMT
              , SUM(T.OFLN_WON_ARSE_NSALAMT)                                                                                                                                                               AS OFLN_WON_ARSE_NSALAMT
              , SUM(T.OFLN_DLR_ARSE_NSALAMT)                                                                                                                                                               AS OFLN_DLR_ARSE_NSALAMT
              , SUM(T.OMNI_WON_EXCH_NSALAMT)                                                                                                                                                               AS OMNI_WON_EXCH_NSALAMT
              , SUM(T.OMNI_DLR_EXCH_NSALAMT)                                                                                                                                                               AS OMNI_DLR_EXCH_NSALAMT
              , SUM(T.OMNI_WON_NSALAMT)                                                                                                                                                                    AS OMNI_WON_NSALAMT
              , SUM(T.OMNI_DLR_NSALAMT)                                                                                                                                                                    AS OMNI_DLR_NSALAMT
              , MAX(T.RGSTPSN_ID)                                                                                                                                                                          AS RGSTPSN_ID
              , MAX(T.USR_NM)                                                                                                                                                                              AS USR_NM
              , MAX(T.RGST_DEPTCD)                                                                                                                                                                         AS RGST_DEPTCD
              , MAX(T.DEPT_NM)                                                                                                                                                                             AS DEPT_NM
               FROM (SELECT /* FE_MK_PRMTN_ACTRSLT FE_MK_������(�¶���) */ 
                            A6.LGPRCD
                          , A1.LGPROMO_NM 
                          , A6.MDPRCD
                          , A2.MIDPROMO_NM 
                          , A6.PRMTNCD
                          , A3.PRMTN_NM
                          , A3.ONOFF_DVS_CD                                                                                                     AS CHNL_TYPE_CD              /* ä�α���(1:��������,2:�¶���) */
                          , A3.PRMTN_LGCSF_CD                                                                                                   AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
                          , A4.PRMTN_LGCSF_NM                                                                                                   AS PRMTN_LGCSF_NM            /* ����з��ڵ� */                                              
                          , A3.PRMTN_MDCSF_CD                                                                                                   AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */ 
                          , A5.PRMTN_MDCSF_NM                                                                                                   AS PRMTN_MDCSF_NM            /* ����ߺз��� */ 
                          , A3.PRMTN_STRT_DT                                                                                                    AS PRMTN_STRT_DT             /* ���������� */
                          , A3.PRMTN_END_DT                                                                                                     AS PRMTN_END_DT              /* ����������� */
                          , A6.INTG_MEMB_NO                                                                                                     AS INTG_MEMB_NO              /* ����ȸ����ȣ */
                          , A6.WON_NSALAMT                                                                                                      AS WON_EXCH_NSALAMT          /* ��ȭ��ȯ�Ǽ������(=��ȭ�������) */
                          , A6.DLR_NSALAMT                                                                                                      AS DLR_EXCH_NSALAMT          /* �޷���ȯ�Ǽ������(=�޷��������) */
                          , (CASE WHEN A6.DLR_NSALAMT       IS NOT NULL THEN A6.INTG_MEMB_NO ELSE NULL END)                   AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                          , A6.WON_PRMTN_NSALAMT                                                                                                AS WON_PRMTN_NSALAMT         /* ��ȭ��������� */
                          , A6.DLR_PRMTN_NSALAMT                                                                                                AS DLR_PRMTN_NSALAMT         /* �޷���������� */
                          , (CASE WHEN A6.DLR_PRMTN_NSALAMT IS NOT NULL THEN A6.INTG_MEMB_NO ELSE NULL END)                   AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                          , A6.WON_LDFP_ACMLT_AMT                                                                                               AS WON_LDFP_ACMLT_AMT        /* LDFPAY �����ݾ�(��ȭ) */
                          , A6.LDFP_ACMLT_CNT                                                                                                   AS LDFP_ACMLT_CNT            /* LDFPAY �����Ǽ� */
                          , NULL                                                                                                                AS FREELDFP_USE_AMT          /* ����LDFPAY���ݾ� */
                          , NULL                                                                                                                AS FREELDFP_USE_CNT          /* ����LDFPAY���Ǽ� */
                          , NULL                                                                                                                AS FREELDFP_ACMLT_AMT        /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                          , NULL                                                                                                                AS FREELDFP_ACMLT_CNT        /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                          , A6.DC_CNT                                                                                                           AS DC_CNT                    /* ���ΰǼ� */
                          , NULL                                                                                                                AS FGF_PRESTAT_AMT           /* ����ǰ�����ݾ� */
                          , NULL                                                                                                                AS FGF_PRESTAT_CNT           /* ����ǰ�����Ǽ� */
                          , A6.ACMLTMN_OFFR_CNT                                                                                                 AS ACMLTMN_OFFR_CNT          /* �����������Ǽ�  */   
                          , NULL                                                                                                                AS DLR_ACMLTMN_OFFR_AMT      /* ��ȭ�����������ݾ�(�޷�)  */  
                          , NULL                                                                                                                AS ACMLTMN_USE_CNT           /* �����ݻ��Ǽ�  */   
                          , NULL                                                                                                                AS ACMLTMN_OFFR_CUST         /* �������������� */
                          , A6.WON_ACMLTMN_PYF_AMT                                                                                              AS WON_ACMLTMN_PYF_AMT       /* ��ȭ�����ݰ����ݾ�  */  
                          , (A6.WON_ACMLTMN_USE_NSALAMT + A6.WON_LDFP_ACMLT_AMT)                                                                   AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü)(=��ȭ�����ݻ�������� + ��ȭLDFPAY�����ݾ�(�����ݾ�)) */
                          , (A6.ACMLTMN_OURCOM_BDN_AMT + A6.LDFP_OURCOM_BDN_AMT)                                                                AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���)(=�������δ�ݾ�) */
                          , (A6.ACMLTMN_ALYCO_BDN_AMT  + A6.LDFP_ALYCO_BDN_AMT)                                                                 AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�)(=�������޻�δ�ݾ�) */                     
                          , A6.DC_OURCOM_BDN_AMT                                                                                                AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                          , A6.DC_ALYCO_BDN_AMT                                                                                                 AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */  
                          , A6.WON_PRMTN_DC_AMT                                                                                                 AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ�  */
                          , A6.WON_ARSE_NSALAMT                                                                                                 AS WON_ARSE_NSALAMT          /* ��ȭ�������߸���(��ȭ���߼������) */
                          , A6.DLR_ARSE_NSALAMT                                                                                                 AS DLR_ARSE_NSALAMT          /* �޷��������߸���(�޷����߼������) */
                          , NULL                                                                                                                AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸��� */
                          , NULL                                                                                                                AS ONLN_DLR_ARSE_NSALAMT     /* �����������߸��� */  
                          , A6.WON_ARSE_NSALAMT                                                                                                 AS OFLN_WON_ARSE_NSALAMT     /* �������ο�ȭ���߼������ (=��ȭ���߼������) */ 
                          , A6.DLR_ARSE_NSALAMT                                                                                                 AS OFLN_DLR_ARSE_NSALAMT     /* �������δ޷����߼������ (=�޷����߼������) */       
                          , A6.OMNI_WON_EXCH_NSALAMT                                                                                            AS OMNI_WON_EXCH_NSALAMT     /* �ȴϿ�ȭ��ȯ�Ǽ������ */                     
                          , A6.OMNI_DLR_EXCH_NSALAMT                                                                                            AS OMNI_DLR_EXCH_NSALAMT     /* �ȴϴ޷���ȯ�Ǽ������ */
                          , A6.OMNI_WON_NSALAMT                                                                                                 AS OMNI_WON_NSALAMT          /* �ȴϱ�ȯ�Ǽ������ */       
                          , A6.OMNI_DLR_NSALAMT                                                                                                 AS OMNI_DLR_NSALAMT          /* �ȴϴ޷�������� */
                          , A3.RGSTPSN_ID                                                                                                       AS RGSTPSN_ID                /* �����ID */
                          , A7.USR_NM                                                                                                           AS USR_NM                    /* ����ڸ� */
                          , A3.RGST_DEPTCD                                                                                                      AS RGST_DEPTCD               /* ��Ϻμ�ID */
                          , A8.DEPT_NM                                                                                                          AS DEPT_NM                   /* ��Ϻμ��� */
                       FROM LDF_DW.D_LGPROMO  A1 
                          , LDF_DW.D_MIDPROMO A2
                          , LDF_DW.D_PRMTN    A3
                          , LDF_DW.D_PRMTN_LGCSF A4
                          , LDF_DW.D_PRMTN_MDCSF A5
                          , LDF_DW.FE_MK_PRMTN_ACTRSLT A6  /* FE_MK_������(�¶���)  */
                          , LDF_DW.D_USR  A7
                          , LDF_DW.D_DEPT A8
                      WHERE 1=1
             ]]><if test='chnlTypeCd != null and chnlTypeCd == "02"'>
                            AND 1=2
                    </if>
                        AND A1.LGPRCD         = A2.LGPRCD 
                        AND A2.MDPRCD         = A3.MDPRCD 
                        AND A3.PRMTN_LGCSF_CD = A4.PRMTN_LGCSF_CD (+) 
                        AND A3.PRMTN_MDCSF_CD = A5.PRMTN_MDCSF_CD (+)
                        AND A3.PRMTNCD        = A6.PRMTNCD
                        AND A3.RGSTPSN_ID     = A7.EMPNO (+)
                        AND A3.RGST_DEPTCD    = A8.DEPTCD (+)
                            /* ��ȸ���� */
             <if test='prmtnDvsCd != null and prmtnDvsCd != "" and prmtncd != null and prmtncd != ""'>
                        <choose>
                            <when test='prmtnDvsCd == "1"'> <!-- ����� -->
                            AND A3.LGPRCD = #{prmtncd}
                            </when>
                            <when test='prmtnDvsCd == "2"'> <!-- ����� -->
                            AND A3.MDPRCD = #{prmtncd}
                            </when>
                            <when test='prmtnDvsCd == "3"'> <!-- ����� -->
                            AND A3.PRMTNCD = #{prmtncd}
                            </when>
                        </choose>
                    </if>
          <if test='inqryStrtDt != null and inqryStrtDt != ""'>
                            AND A6.STD_DT <![CDATA[>=]]> #{inqryStrtDt}  /* ��ȸ ������ */
                    </if>
                    <if test='inqryEndDt != null and inqryEndDt != ""'>
                            AND A6.STD_DT <![CDATA[<=]]> #{inqryEndDt}  /* ��ȸ ������ */
                    </if>
                    <if test='(langCd != null and langCd != "") or (langCds != null)'>
                            AND A3.PRMTNCD  IN (SELECT A3.PRMTNCD 
                                                  FROM LDF_DW.WL_LC_PRMTN_OFFR_CNDT A3
                                                 WHERE 1                      = 1
                                                   AND A3.PRMTN_OFFR_CNDT_CD  = '01'
                                                   AND A3.CHNL_TYPE_CD        = '01'
                    <if test='langCd != null and langCd != ""'>
                                                   AND A3.PRMTN_CNDT_VAL      = #{langCd} /* ��ȸ���� - ��� */
                    </if>
                    <if test='langCds != null'>
                                                   AND A3.PRMTN_CNDT_VAL     IN <foreach collection="langCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ��� */
                    </if>
                            )
                    </if><![CDATA[
                UNION ALL
                     SELECT /* FL_MK_PRMTN_ACTRSLT FL_MK_������(��������) */  
                            A6.LGPRCD
                          , A1.LGPROMO_NM 
                          , A6.MDPRCD
                          , A2.MIDPROMO_NM 
                          , A6.PRMTNCD
                          , A3.PRMTN_NM 
                          , A3.ONOFF_DVS_CD                                                                                                       AS CHNL_TYPE_CD              /* ä�α���(1:��������,2:�¶���) */
                          , A3.PRMTN_LGCSF_CD                                                                                                     AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
                          , A4.PRMTN_LGCSF_NM                                                                                                     AS PRMTN_LGCSF_NM            /* ����з��ڸ� */ 
                          , A3.PRMTN_MDCSF_CD                                                                                                     AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */
                          , A5.PRMTN_MDCSF_NM                                                                                                     AS PRMTN_MDCSF_NM            /* ����ߺз��� */ 
                          , A3.PRMTN_STRT_DT                                                                                                      AS PRMTN_STRT_DT             /* ���������� */
                          , A3.PRMTN_END_DT                                                                                                       AS PRMTN_END_DT              /* ����������� */
                          , A6.INTG_MEMB_NO                                                                                                       AS INTG_MEMB_NO              /* ����ȸ����ȣ */
                          , A6.WON_EXCH_NSALAMT                                                                                                   AS WON_EXCH_NSALAMT          /* ��ȭ��ȯ�Ǽ������ */
                          , A6.DLR_EXCH_NSALAMT                                                                                                   AS DLR_EXCH_NSALAMT          /* �޷���ȯ�Ǽ������ */
                          , (CASE WHEN A6.DLR_EXCH_NSALAMT  IS NOT NULL THEN A6.INTG_MEMB_NO ELSE NULL END)                       AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                          , A6.WON_PRMTN_NSALAMT                                                                                                  AS WON_PRMTN_NSALAMT         /* ��ȭ��������� */
                          , A6.DLR_PRMTN_NSALAMT                                                                                                  AS DLR_PRMTN_NSALAMT         /* �޷���������� */
                          , (CASE WHEN A6.DLR_PRMTN_NSALAMT IS NOT NULL THEN A6.INTG_MEMB_NO ELSE NULL END)                       AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                          , A6.LDFP_ACMLT_AMT                                                                                                     AS WON_LDFP_ACMLT_AMT        /* LDFPAY �����ݾ� */
                          , A6.LDFP_ACMLT_CNT                                                                                                     AS LDFP_ACMLT_CNT            /* LDFPAY �����Ǽ� */
                          , A6.FREELDFP_USE_AMT                                                                                                   AS FREELDFP_USE_AMT          /* ����LDFPAY���ݾ� */
                          , A6.FREELDFP_USE_CNT                                                                                                   AS FREELDFP_USE_CNT          /* ����LDFPAY���Ǽ� */
                          , A6.FREELDFP_ACMLT_AMT                                                                                                 AS FREELDFP_ACMLT_AMT        /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                          , A6.FREELDFP_ACMLT_CNT                                                                                                 AS FREELDFP_ACMLT_CNT        /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                          , A6.DC_CNT                                                                                                             AS DC_CNT                    /* ���ΰǼ� */
                          , A6.FGF_PRESTAT_AMT                                                                                                    AS FGF_PRESTAT_AMT           /* ����ǰ�����ݾ� */
                          , A6.FGF_PRESTAT_CNT                                                                                                    AS FGF_PRESTAT_CNT           /* ����ǰ�����Ǽ� */
                          , NULL                                                                                                                  AS ACMLTMN_OFFR_CNT          /* �����������Ǽ�  */   
                          , NULL                                                                                                                  AS DLR_ACMLTMN_OFFR_AMT      /* ��ȭ�����������ݾ�(�޷�)  */  
                          , NULL                                                                                                                  AS ACMLTMN_USE_CNT           /* �����ݻ��Ǽ�  */  
                          , NULL                                                                                                                  AS ACMLTMN_OFFR_CUST         /* �������������� */
                          , NULL                                                                                                                  AS WON_ACMLTMN_PYF_AMT       /* ��ȭ�����ݰ����ݾ�  */ 
                          , (A6.FGF_PRESTAT_AMT + A6.LDFP_ACMLT_AMT + A6.FREELDFP_USE_AMT)                                                        AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü)(=����ǰ�����ݾ� + LDFPAY�����ݾ� + ����LDFPAY���ݾ�) */
                          , A6.PRESTAT_OURCOM_BDN_AMT                                                                                             AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���)(=�������δ�ݾ�) */
                          , A6.PRESTAT_ALYCO_BDN_AMT                                                                                              AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�)(=�������޻�δ�ݾ�) */                     
                          , A6.DC_OURCOM_BDN_AMT                                                                                                  AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                          , A6.DC_ALYCO_BDN_AMT                                                                                                   AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */  
                          , A6.WON_PRMTN_DC_AMT                                                                                                     AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ�(��ȭ������αݾ�)  */
                          , A6.WON_ARSE_NSALAMT                                                                                                   AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ���߼������) */
                          , A6.DLR_ARSE_NSALAMT                                                                                                   AS DLR_ARSE_NSALAMT          /* �޷��������߸���(�޷����߼������) */
                          , A6.WON_CROS_ARSE_NSALAMT                                                                                              AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸��� */
                          , A6.DLR_CROS_ARSE_NSALAMT                                                                                              AS ONLN_DLR_ARSE_NSALAMT     /* �����������߸��� */  
                          , A6.WON_ARSE_NSALAMT                                                                                                                  AS OFLN_WON_ARSE_NSALAMT     /* �������ο�ȭ���߼������ (=��ȭ�������߼������) */ 
                          , A6.DLR_ARSE_NSALAMT                                                                                                                  AS OFLN_DLR_ARSE_NSALAMT     /* �������δ޷����߼������ (=�޷��������߼������) */       
                          , A6.OMNI_WON_EXCH_NSALAMT                                                                                              AS OMNI_WON_EXCH_NSALAMT     /* �ȴϿ�ȭ��ȯ�Ǽ������ */                     
                          , A6.OMNI_DLR_EXCH_NSALAMT                                                                                              AS OMNI_DLR_EXCH_NSALAMT     /* �ȴϴ޷���ȯ�Ǽ������ */
                          , A6.OMNI_WON_NSALAMT                                                                                                   AS OMNI_WON_NSALAMT          /* �ȴϱ�ȯ�Ǽ������ */       
                          , A6.OMNI_DLR_NSALAMT                                                                                                   AS OMNI_DLR_NSALAMT          /* �ȴϴ޷�������� */
                          , A3.RGSTPSN_ID                                                                                                         AS RGSTPSN_ID                /* �����ID */
                          , A7.USR_NM                                                                                                             AS USR_NM                    /* ����ڸ� */
                          , A3.RGST_DEPTCD                                                                                                        AS RGST_DEPTCD               /* ��Ϻμ�ID */
                          , A8.DEPT_NM                                                                                                            AS DEPT_NM                   /* ��Ϻμ��� */
                       FROM LDF_DW.D_LGPROMO  A1 
                          , LDF_DW.D_MIDPROMO A2
                          , LDF_DW.D_PRMTN    A3
                          , LDF_DW.D_PRMTN_LGCSF A4
                          , LDF_DW.D_PRMTN_MDCSF A5
                          , LDF_DW.FL_MK_PRMTN_ACTRSLT A6  /* FL_MK_������(��������)  */
                          , LDF_DW.D_USR  A7
                          , LDF_DW.D_DEPT A8
                      WHERE 1=1
             ]]><if test='chnlTypeCd != null and chnlTypeCd == "01"'>
                            AND 1=2
                    </if>
                        AND A1.LGPRCD         = A2.LGPRCD 
                        AND A2.MDPRCD         = A3.MDPRCD 
                        AND A3.PRMTN_LGCSF_CD = A4.PRMTN_LGCSF_CD (+)
                        AND A3.PRMTN_MDCSF_CD = A5.PRMTN_MDCSF_CD (+)
                        AND A3.PRMTNCD        = A6.PRMTNCD 
                        AND A3.RGSTPSN_ID     = A7.EMPNO (+)
                        AND A3.RGST_DEPTCD    = A8.DEPTCD (+)
                            /* ��ȸ���� */
         <if test='prmtnDvsCd != null and prmtnDvsCd != "" and prmtncd != null and prmtncd != ""'>
                        <choose>
                            <when test='prmtnDvsCd == "1"'> <!-- ����� -->
                            AND A3.LGPRCD = #{prmtncd}
                            </when>
                            <when test='prmtnDvsCd == "2"'> <!-- ����� -->
                            AND A3.MDPRCD = #{prmtncd}
                            </when>
                            <when test='prmtnDvsCd == "3"'> <!-- ����� -->
                            AND A3.PRMTNCD = #{prmtncd}
                            </when>
                        </choose>
                    </if>
          <if test='inqryStrtDt != null and inqryStrtDt != ""'>
                            AND A6.STD_DT <![CDATA[>=]]> #{inqryStrtDt}  /* ��ȸ ������ */
                    </if>
                    <if test='inqryEndDt != null and inqryEndDt != ""'>
                            AND A6.STD_DT <![CDATA[<=]]> #{inqryEndDt}  /* ��ȸ ������ */
                    </if>
                    <if test='(strCd != null and strCd != "") or (strCds != null) or (biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != "") or (biznsStrLoctnDvsCds != null)'>
                            AND A3.PRMTNCD  IN (SELECT PRMTNCD
                                                  FROM LDF_DW.WL_LC_PRMTN_OFFR_CNDT A3
                                                     , LDF_DW.D_STR A4
                                                 WHERE 1                          = 1
                                                   AND A3.PRMTN_CNDT_VAL          = A4.STR_CD
                                                   AND A3.PRMTN_OFFR_CNDT_CD      = '01'
                                                   AND A3.CHNL_TYPE_CD            = '02'
                        <if test='strCd != null and strCd != ""'>
                                                   AND A3.PRMTN_CNDT_VAL          = #{strCd} /* ��ȸ���� - ���� */
                        </if>
                        <if test='strCds != null'>
                                                   AND A3.PRMTN_CNDT_VAL         IN <foreach collection="strCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ���� */
                        </if>
                        <if test='biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != ""'>
                                                   AND A4.BIZNS_STR_LOCTN_DVS_CD  = #{biznsStrLoctnDvsCd} /* ��ȸ���� - ��������ġ���� */
                        </if>
                        <if test='biznsStrLoctnDvsCds != null'>
                                                   AND A4.BIZNS_STR_LOCTN_DVS_CD IN <foreach collection="biznsStrLoctnDvsCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ��������ġ���� */
                        </if>
                              )
                    </if><![CDATA[
                      UNION ALL
                     SELECT /* FE_MK_����OFFER�� */
                            A1.LGPRCD                                                 AS LGPRCD
                          , A2.LGPROMO_NM                                             AS LGPROMO_NM
                          , A1.MDPRCD                                                 AS MDPRCD
                          , A3.MIDPROMO_NM                                            AS MIDPROMO_NM
                          , A1.PRMTNCD                                                AS PRMTNCD 
                          , A1.PRMTN_NM                                               AS PRMTN_NM
                          , A1.ONOFF_DVS_CD                                           AS CHNL_TYPE_CD
                          , A1.PRMTN_LGCSF_CD                                         AS PRMTN_LGCSF_CD
                          , A4.PRMTN_LGCSF_NM                                         AS PRMTN_LGCSF_NM
                          , A1.PRMTN_MDCSF_CD                                         AS PRMTN_MDCSF_CD
                          , A5.PRMTN_MDCSF_NM                                         AS PRMTN_MDCSF_NM
                          , A1.PRMTN_STRT_DT                                          AS PRMTN_STRT_DT
                          , A1.PRMTN_END_DT                                           AS PRMTN_END_DT
                          , NULL                                                      AS INTG_MEMB_NO              /* ����ȸ����ȣ */
                          , 0                                                         AS WON_EXCH_NSALAMT          /* ��ȭ��ȯ�Ǽ������ */
                          , 0                                                         AS DLR_EXCH_NSALAMT          /* �޷���ȯ�Ǽ������ */
                          , NULL                                                      AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                          , 0                                                         AS WON_PRMTN_NSALAMT         /* ��ȭ��������� */
                          , 0                                                         AS DLR_PRMTN_NSALAMT         /* �޷���������� */
                          , NULL                                                      AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                          , 0                                                         AS WON_LDFP_ACMLT_AMT        /* LDFPAY �����ݾ� */
                          , 0                                                         AS LDFP_ACMLT_CNT            /* LDFPAY �����Ǽ� */
                          , 0                                                         AS FREELDFP_USE_AMT          /* ����LDFPAY���ݾ� */
                          , 0                                                         AS FREELDFP_USE_CNT          /* ����LDFPAY���Ǽ� */
                          , 0                                                         AS FREELDFP_ACMLT_AMT        /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                          , 0                                                         AS FREELDFP_ACMLT_CNT        /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                          , 0                                                         AS DC_CNT                    /* ���ΰǼ� */
                          , 0                                                         AS FGF_PRESTAT_AMT           /* ����ǰ�����ݾ� */
                          , 0                                                         AS FGF_PRESTAT_CNT           /* ����ǰ�����Ǽ� */
                          , 0                                                         AS ACMLTMN_OFFR_CNT          /* �����������Ǽ� */
                          , A1.DLR_ACMLTMN_OFFR_AMT                                   AS DLR_ACMLTMN_OFFR_AMT      /* �����������ݾ�(�޷�) */
                          , A1.ACMLTMN_OFFR_CNT                                       AS ACMLTMN_USE_CNT           /* �����ݻ��Ǽ� */
                          , A1.ACMLTMN_OFFR_CUST_NBR                                  AS ACMLTMN_OFFR_CUST         /* �������������� */
                          , 0                                                         AS WON_ACMLTMN_PYF_AMT       /* ��ȭ�����ݰ����ݾ�  */  
                          , 0                                                         AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü)(=���+���޻�) */
                          , 0                                                         AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���)(=�������δ�ݾ�) */
                          , 0                                                         AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�)(=�������޻�δ�ݾ�) */                     
                          , 0                                                         AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                          , 0                                                         AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */  
                          , 0                                                         AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ�  */ 
                          , 0                                                         AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ���߼������) */
                          , 0                                                         AS DLR_ARSE_NSALAMT          /* �޷��������߸���(�޷����߼������) */
                          , 0                                                         AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸��� */
                          , 0                                                         AS ONLN_DLR_ARSE_NSALAMT     /* �����������߸��� */  
                          , 0                                                         AS OFLN_WON_ARSE_NSALAMT     /* �������ο�ȭ���߼������ (=��ȭ�������߼������) */ 
                          , 0                                                         AS OFLN_DLR_ARSE_NSALAMT     /* �������δ޷����߼������ (=�޷��������߼������) */       
                          , 0                                                         AS OMNI_WON_EXCH_NSALAMT     /* �ȴϿ�ȭ��ȯ�Ǽ������ */                     
                          , 0                                                         AS OMNI_DLR_EXCH_NSALAMT     /* �ȴϴ޷���ȯ�Ǽ������ */
                          , 0                                                         AS OMNI_WON_NSALAMT          /* �ȴϱ�ȯ�Ǽ������ */       
                          , 0                                                         AS OMNI_DLR_NSALAMT          /* �ȴϴ޷�������� */
                          , A1.RGSTPSN_ID                                             AS RGSTPSN_ID                /* �����ID */
                          , A6.USR_NM                                                 AS USR_NM                    /* ����ڸ� */
                          , A1.RGST_DEPTCD                                            AS RGST_DEPTCD               /* ��Ϻμ�ID */
                          , A7.DEPT_NM                                                AS DEPT_NM                   /* ��Ϻμ��� */
                       FROM (SELECT /*+ PARALLEL(4) USE_HASH(B1,B4)  FULL(B1) FULL(B4)*/
                                    B1.PRMTNCD                      AS PRMTNCD 
                                  , B1.PRMTN_NM                     AS PRMTN_NM
                                  , MAX(B1.LGPRCD)                  AS LGPRCD
                                  , MAX(B1.MDPRCD)                  AS MDPRCD
                                  , MAX(B1.PRMTN_STRT_DT)           AS PRMTN_STRT_DT 
                                  , MAX(B1.PRMTN_END_DT)            AS PRMTN_END_DT 
                                  , MAX(B1.ONOFF_DVS_CD)            AS ONOFF_DVS_CD 
                                  , MAX(B1.PRMTN_LGCSF_CD)          AS PRMTN_LGCSF_CD 
                                  , MAX(B1.PRMTN_MDCSF_CD)          AS PRMTN_MDCSF_CD 
                                  , MAX(B1.RGSTPSN_ID)              AS RGSTPSN_ID 
                                  , MAX(B1.RGST_DEPTCD)             AS RGST_DEPTCD 
                                  , COUNT(DISTINCT B4.INTG_MEMB_NO) AS ACMLTMN_OFFR_CUST_NBR /* �����������Ǽ� */
                                  , SUM(B4.OFFER_PRESTAT_CNT)       AS ACMLTMN_OFFR_CNT /* ����������_�Ǽ� */
                                  , SUM(B4.DLR_OFFER_PRESTAT_AMT)   AS DLR_ACMLTMN_OFFR_AMT /* �޷������������ݾ� */        
                               FROM (SELECT B3.PRMTNCD
                                          , B3.PRMTN_NM
                                          , B3.LGPRCD
                                          , B3.MDPRCD
                                          , B3.PRMTN_STRT_DT
                                          , B3.PRMTN_END_DT
                                          , B3.ONOFF_DVS_CD
                                          , B3.PRMTN_LGCSF_CD
                                          , B3.PRMTN_MDCSF_CD
                                          , B3.RGSTPSN_ID
                                          , B3.RGST_DEPTCD
                                          , B6.BNFT_OBJ_NO      AS ONLN_OFFER_NO  /* ���ô���ȣ */
                                          , B6.PRMTN_BNFT_NO    AS PRMTN_BNFT_NO  /* ������ù�ȣ */
                                       FROM LDF_DW.D_PRMTN B3
                                          , LDF_DW.WL_LC_PRMTN_BNFT B6
                                      WHERE 1=1
                        AND B3.PRMTNCD        = B6.PRMTNCD 
                                        AND B3.PRMTN_LGCSF_CD = '007' /* ������ */
             ]]><if test='prmtnDvsCd != null and prmtnDvsCd != "" and prmtncd != null and prmtncd != ""'>
                        <choose>
                            <when test='prmtnDvsCd == "1"'> <!-- ����� -->
                                            AND B3.LGPRCD         = #{prmtncd} /* �������� - ������ڵ� */
                            </when>
                            <when test='prmtnDvsCd == "2"'> <!-- ����� -->
                                            AND B3.MDPRCD         = #{prmtncd}       /* �������� - ������ڵ� */
                            </when>
                            <when test='prmtnDvsCd == "3"'> <!-- ����� -->
                                            AND B3.PRMTNCD        = #{prmtncd}      /* �������� - ������ڵ� */
                            </when>
                        </choose>
                    </if>
                                    ) B1
                                  , LDF_DW.FE_MK_BNFT_OFFER_DTL B4
                              WHERE 1=1
                                AND B4.STD_DT       BETWEEN B1.PRMTN_STRT_DT AND B1.PRMTN_END_DT 
                                AND B4.STD_TM_VAL        >= '00'
                                AND B4.ONLN_OFFER_NO      = B1.ONLN_OFFER_NO 
                                AND B4.PRMTN_BNFT_NO      = B1.PRMTN_BNFT_NO 
                                AND B4.OFFER_PRESTAT_CNT <![CDATA[<>]]> 0 /* �����Ǽ� 0�� �ƴѰ�� */
                                
          <if test='inqryStrtDt != null and inqryStrtDt != ""'>
                                    AND B4.STD_DT <![CDATA[>=]]> #{inqryStrtDt}  /* ��ȸ ������ */
                    </if>
                    <if test='inqryEndDt != null and inqryEndDt != ""'>
                                    AND B4.STD_DT <![CDATA[<=]]> #{inqryEndDt}  /* ��ȸ ������ */
                    </if>
                              GROUP BY B1.PRMTNCD
                                     , B1.PRMTN_NM
                            ) A1
                          , LDF_DW.D_LGPROMO A2
                          , LDF_DW.D_MIDPROMO A3
                          , LDF_DW.D_PRMTN_LGCSF A4
                          , LDF_DW.D_PRMTN_MDCSF A5
                          , LDF_DW.D_USR A6
                          , LDF_DW.D_DEPT A7
                      WHERE 1=1
                        AND A1.LGPRCD         = A2.LGPRCD 
                        AND A1.MDPRCD         = A3.MDPRCD
                        AND A1.PRMTN_LGCSF_CD = A4.PRMTN_LGCSF_CD (+)
                        AND A1.PRMTN_MDCSF_CD = A5.PRMTN_MDCSF_CD (+)
                        AND A1.RGSTPSN_ID     = A6.EMPNO (+)
                        AND A1.RGST_DEPTCD    = A7.DEPTCD (+)
            <if test='(strCd != null and strCd != "") or (strCds != null) or (biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != "") or (biznsStrLoctnDvsCds != null)'>
                            AND A1.PRMTNCD      IN (SELECT PRMTNCD 
                                                      FROM LDF_DW.WL_LC_PRMTN_OFFR_CNDT A3
                                                         , LDF_DW.D_STR A4
                                                     WHERE 1                          = 1
                                                       AND A3.PRMTN_CNDT_VAL          = A4.STR_CD
                                                       AND A3.PRMTN_OFFR_CNDT_CD      = '01'
                                                       AND A3.CHNL_TYPE_CD            = '02'
                        <if test='strCd != null and strCd != ""'>
                                                       AND A3.PRMTN_CNDT_VAL          = #{strCd} /* ��ȸ���� - ���� */
                        </if>
                        <if test='strCds != null'>
                                                       AND A3.PRMTN_CNDT_VAL         IN <foreach collection="strCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ���� */
                        </if>
                        <if test='biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != ""'>
                                                       AND A4.BIZNS_STR_LOCTN_DVS_CD  = #{biznsStrLoctnDvsCd} /* ��ȸ���� - ��������ġ���� */
                        </if>
                        <if test='biznsStrLoctnDvsCds != null'>
                                                       AND A4.BIZNS_STR_LOCTN_DVS_CD IN <foreach collection="biznsStrLoctnDvsCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ��������ġ���� */
                        </if>
                                                    )
                    </if>
                    ) T
              GROUP BY T.LGPRCD                                                                                                                                                          
                  , T.LGPROMO_NM                                                                                                                                                     
                  , T.MDPRCD                                                                                                                                                          
                  , T.MIDPROMO_NM                                                                                                                                                    
                  , T.PRMTNCD                                                                                                                                                         
                  , T.PRMTN_NM        
           ) M
           ;
           
           
--2. �����뺰
SELECT M.LGPRCD                              AS LGPRCD                    /* ������ڵ� */
              , M.LGPROMO_NM                          AS LGPROMO_NM                /* ������ */
              , M.MDPRCD                              AS MDPRCD                    /* ������ڵ� */
              , M.MIDPROMO_NM                         AS MIDPROMO_NM               /* ������ */
              , M.PRMTNCD                             AS PRMTNCD                   /* ������ڵ� */
              , M.PRMTN_NM                            AS PRMTN_NM                  /* ������ */
              , M.STR_CD                              AS STR_LANG_CD               /* ����/����ڵ� */
              , (SELECT B1.STR_NM
                   FROM LDF_DW.D_STR B1
                  WHERE B1.STR_CD = M.STR_CD
                 )                                     AS STR_LANG_NM               /* ����/���� */
              , M.PRMTN_LGCSF_CD                       AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
              , M.PRMTN_LGCSF_NM                       AS PRMTN_LGCSF_NM            /* ����з��� */
              , M.PRMTN_MDCSF_CD                       AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */
              , M.PRMTN_MDCSF_NM                       AS PRMTN_MDCSF_NM            /* ����з��� */
              , M.PRMTN_APLY_STRT_AMT                  AS PRMTN_APLY_STRT_AMT           /* ������ݾ� */
              , M.PRMTN_STRT_DT                        AS PRMTN_STRT_DT             /* ���������� */
              , M.PRMTN_END_DT                         AS PRMTN_END_DT              /* ����������� */
              , NVL(M.WON_EXCH_NSALAMT,0)              AS WON_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(��ȭ) */
              , NVL(M.DLR_EXCH_NSALAMT,0)              AS DLR_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(�޷�) */
              , NVL(M.EXCH_SALES_CNT,0)                AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
              , NVL(M.WON_ARSE_NSALAMT_CUSTRN,0)       AS WON_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(��ȭ) */
              , NVL(M.DLR_ARSE_NSALAMT_CUSTRN,0)       AS DLR_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(�޷�) */
              , NVL(M.WON_PRMTN_NSALAMT,0)             AS WON_PRMTN_NSALAMT         /* ������_����(��ȭ) */
              , NVL(M.DLR_PRMTN_NSALAMT,0)             AS DLR_PRMTN_NSALAMT         /* ������_����(�޷�) */
              , NVL(M.PRMTN_NSALAMT_CNT,0)             AS PRMTN_NSALAMT_CNT         /* ������_�������� */
              , NVL(M.WON_PRMTN_NSALAMT_CUSTRN,0)      AS WON_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(��ȭ) */
              , NVL(M.DLR_PRMTN_NSALAMT_CUSTRN,0)      AS DLR_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(�޷�) */
              , NVL(M.WON_LDFP_ACMLT_AMT,0)            AS WON_LDFP_ACMLT_AMT        /* LDFPAY_�����ݾ�(��ȭ) */
              , NVL(M.LDFP_ACMLT_CNT,0)                AS LDFP_ACMLT_CNT            /* LDFPAY_�����Ǽ� */
              , NVL(M.LDFP_ACMLT_CUST_NBR,0)           AS LDFP_ACMLT_CUST_NBR       /* LDFPAY_�������� */
              , NVL(M.FREELDFP_USE_AMT,0)              AS FREELDFP_USE_AMT          /* FREE_LDFPAY_���ݾ� */
              , NVL(M.FREELDFP_USE_CNT,0)              AS FREELDFP_USE_CNT          /* FREE_LDFPAY_���Ǽ� */
              , NVL(M.FREELDFP_USE_CUST_NBR,0)         AS FREELDFP_USE_CUST_NBR     /* FREE_LDFPAY_��밴�� */
              , NVL(M.FREELDFP_ACMLT_AMT,0)            AS FREELDFP_ACMLT_AMT        /* FREE_LDFPAY_�����ݾ� */
              , NVL(M.FREELDFP_ACMLT_CNT,0)            AS FREELDFP_ACMLT_CNT        /* FREE_LDFPAY_�����Ǽ� */
              , NVL(M.FREELDFP_ACLMLT_CUST_NBR,0)      AS FREELDFP_ACLMLT_CUST_NBR  /* FREE_LDFPAY_�������� */
              , NVL(M.DC_AMT,0)                        AS DC_AMT                    /* ����_�ݾ� */
              , NVL(M.DC_CNT,0)                        AS DC_CNT                    /* ����_�Ǽ� */
              , NVL(M.BDN_CUST_NBR,0)                  AS BDN_CUST_NBR              /* ����_���� */
              , NVL(M.FGF_PRESTAT_AMT,0)               AS FGF_PRESTAT_AMT           /* ����ǰ����_�ݾ� */
              , NVL(M.FGF_PRESTAT_CNT,0)               AS FGF_PRESTAT_CNT           /* ����ǰ����_�Ǽ� */
              , NVL(M.FGF_PRESTAT_CUST_NBR,0)          AS FGF_PRESTAT_CUST_NBR      /* ����ǰ����_���� */
              , NVL(M.ACMLTMN_OFFR_CNT,0)              AS ACMLTMN_OFFR_CNT          /* ����������_�Ǽ� */
              , NVL(M.DLR_ACMLTMN_OFFR_AMT,0)          AS DLR_ACMLTMN_OFFR_AMT      /* ����������_�ݾ�(��ȭ) */
              , NVL(M.ACMLTMN_OFFR_CUST_NBR,0)         AS ACMLTMN_OFFR_CUST_NBR     /* ����������_���� */
              , NVL(M.ACMLTMN_USE_CNT,0)               AS ACMLTMN_USE_CNT           /* �����ݻ��_�Ǽ� */
              , NVL(M.WON_ACMLTMN_PYF_AMT,0)           AS WON_ACMLTMN_PYF_AMT       /* �����ݻ��_�ݾ�(��ȭ) */
              , NVL(M.ACMLTMN_USE_CUST_NBR,0)          AS ACMLTMN_USE_CUST_NBR      /* �����ݻ��_���� */
              , NVL(M.TOT_PRESTAT_AMT,0)               AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü) */
              , NVL(M.PRESTAT_OURCOM_BDN_AMT,0)        AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���) */
              , NVL(M.PRESTAT_ALYCO_BDN_AMT,0)         AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�) */
              , NVL(M.TOT_PRESTAT_RATE,0)              AS OURCOM_PRESTAT_RATE          /* ������(��ü) */
              , NVL(M.OURCOM_PRESTAT_RATE,0)           AS TOT_PRESTAT_RATE       /* ������(���) */     
              , NVL(M.TOT_BDN_AMT,0)                   AS TOT_BDN_AMT               /* ���αݾ�(��ü) */
              , NVL(M.DC_OURCOM_BDN_AMT,0)             AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
              , NVL(M.DC_ALYCO_BDN_AMT,0)              AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */
              , NVL(M.TOT_DC_CNT,0)                    AS TOT_DC_CNT                /* ���ΰǼ� */
              , NVL(M.WON_TOT_DC_AMT,0)                AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ� */
              , NVL(M.DC_TOT_BDN_RATE,0)               AS DC_OURCOM_BDN_RATE           /* ������(��ü) */
              , NVL(M.DC_OURCOM_BDN_RATE,0)            AS DC_TOT_BDN_RATE        /* ������(���) */     
		     , NVL(M.TOT_PRESTAT_AMT+M.TOT_BDN_AMT,0) AS PRMTN_EXP                 /* �����(�����ݾ�+���αݾ�) */
		     , NVL(ROUND(((M.TOT_PRESTAT_AMT + M.TOT_BDN_AMT) / DECODE(M.WON_PRMTN_NSALAMT, 0, NULL, M.WON_PRMTN_NSALAMT))*100,1),0) AS INTG_SUPTRT   /* ����������(�����ݾ�+���αݾ�) / ��ȭ��������� */ 
              , NVL(M.WON_ARSE_NSALAMT,0)              AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ) */
              , NVL(M.ONLN_WON_ARSE_NSALAMT,0)         AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸���(��ȭ) */
              , NVL(M.ONLN_DLR_ARSE_NSALAMT,0)         AS ONLN_DLR_ARSE_NSALAMT     /* �¶������߸���(�޷�) */
              , NVL(M.OFLN_WON_ARSE_NSALAMT,0)         AS OFLN_WON_ARSE_NSALAMT     /* �����������߸���(��ȭ) */
              , NVL(M.OFLN_DLR_ARSE_NSALAMT,0)         AS OFLN_DLR_ARSE_NSALAMT     /* �����������߸���(�޷�) */
              , NVL(M.OMNI_WON_EXCH_NSALAMT,0)         AS OMNI_WON_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(��ȭ) */
              , NVL(M.OMNI_DLR_EXCH_NSALAMT,0)         AS OMNI_DLR_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(�޷�) */
              , NVL(M.OMNI_WON_NSALAMT,0)              AS OMNI_WON_NSALAMT          /* ���ȴϸ���(��ȭ) */
              , NVL(M.OMNI_DLR_NSALAMT,0)              AS OMNI_DLR_NSALAMT          /* ���ȴϸ���(�޷�) */
              , M.RGSTPSN_ID                           AS RGSTPSN_ID                /* �����ID */
              , M.USR_NM                               AS RGSTPSN_NM                    /* ����ڸ� */
              , M.RGST_DEPTCD                          AS RGST_DEPTCD               /* ��Ϻμ��ڵ� */
              , M.DEPT_NM                              AS RGST_DEPT_NM                   /* ��Ϻμ��� */
           FROM (SELECT A.LGPRCD                              AS LGPRCD                    /* ������ڵ� */
                      , A.LGPROMO_NM                          AS LGPROMO_NM                /* ������ */
                      , A.MDPRCD                              AS MDPRCD                    /* ������ڵ� */
                      , A.MIDPROMO_NM                         AS MIDPROMO_NM               /* ������ */
                      , A.PRMTNCD                             AS PRMTNCD                   /* ������ڵ� */
                      , A.PRMTN_NM                            AS PRMTN_NM                  /* ������ */
                      , A.STR_CD                              AS STR_CD                   /* �����ڵ� */
                      , A.PRMTN_APLY_STRT_AMT            AS PRMTN_APLY_STRT_AMT           /* ������ݾ� */
                      , MAX(A.PRMTN_LGCSF_CD)                 AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
                      , MAX(A.PRMTN_LGCSF_NM)                 AS PRMTN_LGCSF_NM            /* ����з��� */
                      , MAX(A.PRMTN_MDCSF_CD)                 AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */
                      , MAX(A.PRMTN_MDCSF_NM)                 AS PRMTN_MDCSF_NM            /* ����з��� */
                      , MAX(A.CHNL_TYPE_CD)                   AS CHNL_TYPE_CD              /* ä�� ���� */
                      , MAX(A.PRMTN_STRT_DT)                  AS PRMTN_STRT_DT             /* ���������� */
                      , MAX(A.PRMTN_END_DT)                   AS PRMTN_END_DT              /* ����������� */
                      , MAX(A.WON_EXCH_NSALAMT)               AS WON_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(��ȭ) */
                      , MAX(A.DLR_EXCH_NSALAMT)               AS DLR_EXCH_NSALAMT          /* ��ȯ�Ǹ���_����(�޷�) */
                      , MAX(A.EXCH_SALES_CNT)                 AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                      , MAX(A.WON_ARSE_NSALAMT_CUSTRN)        AS WON_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(��ȭ) */
                      , MAX(A.DLR_ARSE_NSALAMT_CUSTRN)        AS DLR_ARSE_NSALAMT_CUSTRN   /* ��ȯ�Ǹ���_���ܰ�(�޷�) */
                      , MAX(A.WON_PRMTN_NSALAMT)              AS WON_PRMTN_NSALAMT         /* ������_����(��ȭ) */
                      , MAX(A.DLR_PRMTN_NSALAMT)              AS DLR_PRMTN_NSALAMT         /* ������_����(�޷�) */
                      , MAX(A.PRMTN_NSALAMT_CNT)              AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                      , MAX(A.WON_PRMTN_NSALAMT_CUSTRN)       AS WON_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(��ȭ) */
                      , MAX(A.DLR_PRMTN_NSALAMT_CUSTRN)       AS DLR_PRMTN_NSALAMT_CUSTRN  /* ������_���ܰ�(�޷�) */
                      , MAX(A.WON_LDFP_ACMLT_AMT)             AS WON_LDFP_ACMLT_AMT        /* LDFPAY_�����ݾ�(��ȭ) */
                      , MAX(A.LDFP_ACMLT_CNT)                 AS LDFP_ACMLT_CNT            /* LDFPAY_�����Ǽ� */
                      , MAX(A.LDFP_ACMLT_CUST_NBR)            AS LDFP_ACMLT_CUST_NBR       /* LDFPAY_�������� */
                      , MAX(A.FREELDFP_USE_AMT)               AS FREELDFP_USE_AMT          /* FREE_LDFPAY_���ݾ� */
                      , MAX(A.FREELDFP_USE_CNT)               AS FREELDFP_USE_CNT          /* FREE_LDFPAY_���Ǽ� */
                      , MAX(A.FREELDFP_USE_CUST_NBR)          AS FREELDFP_USE_CUST_NBR     /* FREE_LDFPAY_��밴�� */
                      , MAX(A.FREELDFP_ACMLT_AMT)             AS FREELDFP_ACMLT_AMT        /* FREE_LDFPAY_�����ݾ� */
                      , MAX(A.FREELDFP_ACMLT_CNT)             AS FREELDFP_ACMLT_CNT        /* FREE_LDFPAY_�����Ǽ� */
                      , MAX(A.FREELDFP_ACLMLT_CUST_NBR)       AS FREELDFP_ACLMLT_CUST_NBR  /* FREE_LDFPAY_�������� */
                      , MAX(A.DC_AMT)                         AS DC_AMT                    /* ����_�ݾ� */
                      , MAX(A.DC_CNT)                         AS DC_CNT                    /* ����_�Ǽ� */
                      , MAX(A.BDN_CUST_NBR)                   AS BDN_CUST_NBR              /* ����_���� */
                      , MAX(A.FGF_PRESTAT_AMT)                AS FGF_PRESTAT_AMT           /* ����ǰ����_�ݾ� */
                      , MAX(A.FGF_PRESTAT_CNT)                AS FGF_PRESTAT_CNT           /* ����ǰ����_�Ǽ� */
                      , MAX(A.FGF_PRESTAT_CUST_NBR)           AS FGF_PRESTAT_CUST_NBR      /* ����ǰ����_���� */
                      , MAX(A.ACMLTMN_OFFR_CNT)               AS ACMLTMN_OFFR_CNT          /* ����������_�Ǽ� */
                      , MAX(A.DLR_ACMLTMN_OFFR_AMT)           AS DLR_ACMLTMN_OFFR_AMT      /* ����������_�ݾ�(��ȭ) */
                      , MAX(A.ACMLTMN_OFFR_CUST_NBR)          AS ACMLTMN_OFFR_CUST_NBR     /* ����������_���� */
                      , MAX(A.ACMLTMN_USE_CNT)                AS ACMLTMN_USE_CNT           /* �����ݻ��_�Ǽ� */
                      , MAX(A.WON_ACMLTMN_PYF_AMT)            AS WON_ACMLTMN_PYF_AMT       /* �����ݻ��_�ݾ�(��ȭ) */
                      , MAX(A.ACMLTMN_USE_CUST_NBR)           AS ACMLTMN_USE_CUST_NBR      /* �����ݻ��_���� */
                      , MAX(A.TOT_PRESTAT_AMT)                AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü) */
                      , MAX(A.PRESTAT_OURCOM_BDN_AMT)         AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���) */
                      , MAX(A.PRESTAT_ALYCO_BDN_AMT)          AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�) */
                      , MAX(A.TOT_PRESTAT_RATE)               AS TOT_PRESTAT_RATE          /* ������(��ü) */
                      , MAX(A.OURCOM_PRESTAT_RATE)            AS OURCOM_PRESTAT_RATE       /* ������(���) */     
                      , MAX(A.TOT_BDN_AMT)                    AS TOT_BDN_AMT               /* ���αݾ�(��ü) */
                      , MAX(A.DC_OURCOM_BDN_AMT)              AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                      , MAX(A.DC_ALYCO_BDN_AMT)               AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */
                      , MAX(A.TOT_DC_CNT)                     AS TOT_DC_CNT                /* ���ΰǼ� */
                      , MAX(A.WON_TOT_DC_AMT)                 AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ� */
                      , MAX(A.DC_TOT_BDN_RATE)                AS DC_TOT_BDN_RATE           /* ������(��ü) */
                      , MAX(A.DC_OURCOM_BDN_RATE)             AS DC_OURCOM_BDN_RATE        /* ������(���) */     
                      , MAX(A.WON_ARSE_NSALAMT)               AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ) */
                      , MAX(A.ONLN_WON_ARSE_NSALAMT)          AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸���(��ȭ) */
                      , MAX(A.ONLN_DLR_ARSE_NSALAMT)          AS ONLN_DLR_ARSE_NSALAMT     /* �¶������߸���(�޷�) */
                      , MAX(A.OFLN_WON_ARSE_NSALAMT)          AS OFLN_WON_ARSE_NSALAMT     /* �����������߸���(��ȭ) */
                      , MAX(A.OFLN_DLR_ARSE_NSALAMT)          AS OFLN_DLR_ARSE_NSALAMT     /* �����������߸���(�޷�) */
                      , MAX(A.OMNI_WON_EXCH_NSALAMT)          AS OMNI_WON_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(��ȭ) */
                      , MAX(A.OMNI_DLR_EXCH_NSALAMT)          AS OMNI_DLR_EXCH_NSALAMT     /* ��ȯ�ǿȴϸ���(�޷�) */
                      , MAX(A.OMNI_WON_NSALAMT)               AS OMNI_WON_NSALAMT          /* ���ȴϸ���(��ȭ) */
                      , MAX(A.OMNI_DLR_NSALAMT)               AS OMNI_DLR_NSALAMT          /* ���ȴϸ���(�޷�) */
                      , MAX(A.RGSTPSN_ID)                     AS RGSTPSN_ID                /* �����ID */
                      , MAX(A.USR_NM)                         AS USR_NM                    /* ����ڸ� */
                      , MAX(A.RGST_DEPTCD)                    AS RGST_DEPTCD               /* ��Ϻμ��ڵ� */
                      , MAX(A.DEPT_NM)                        AS DEPT_NM                   /* ��Ϻμ��� */         
                   FROM (SELECT T.LGPRCD                                                                                                                                                                                    AS LGPRCD
                              , T.LGPROMO_NM                                                                                                                                                                               AS LGPROMO_NM
                              , T.MDPRCD                                                                                                                                                                                   AS MDPRCD
                              , T.MIDPROMO_NM                                                                                                                                                                              AS MIDPROMO_NM
                              , T.PRMTNCD                                                                                                                                                                                  AS PRMTNCD
                              , T.PRMTN_NM                                                                                                                                                                                 AS PRMTN_NM
                              , T.STR_CD                                                                                                                                                                                   AS STR_CD
							  , T.CMPN_OFFER_NO                                                                                                                                                                            AS CMPN_OFFER_NO
                              , T.PRMTN_SECTRG_NO                                                                                                                                                                          AS PRMTN_SECTRG_NO
                              , T.PRMTN_APLY_STRT_AMT                                                                                                                                                                 AS PRMTN_APLY_STRT_AMT
                              , MAX(T.CHNL_TYPE_CD)                                                                                                                                                                        AS CHNL_TYPE_CD                  /* ����/��� ���� ��(���) */
                              , MAX(T.PRMTN_LGCSF_CD)                                                                                                                                                                      AS PRMTN_LGCSF_CD
                              , MAX(T.PRMTN_LGCSF_NM)                                                                                                                                                                      AS PRMTN_LGCSF_NM
                              , MAX(T.PRMTN_MDCSF_CD)                                                                                                                                                                      AS PRMTN_MDCSF_CD
                              , MAX(T.PRMTN_MDCSF_NM)                                                                                                                                                                      AS PRMTN_MDCSF_NM
                              , MAX(T.PRMTN_STRT_DT)                                                                                                                                                                       AS PRMTN_STRT_DT
                              , MAX(T.PRMTN_END_DT)                                                                                                                                                                        AS PRMTN_END_DT
                              , SUM(T.WON_EXCH_NSALAMT)                                                                                                                                                                    AS WON_EXCH_NSALAMT
                              , SUM(T.DLR_EXCH_NSALAMT)                                                                                                                                                                    AS DLR_EXCH_NSALAMT
                              , COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0    THEN T.EXCH_SALES_CNT  END)                                                                                  						   AS EXCH_SALES_CNT 	     
                              , ROUND(NVL(SUM(T.WON_EXCH_NSALAMT)   
                              / DECODE(COUNT(DISTINCT CASE WHEN T.WON_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.WON_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END)),0))        AS WON_ARSE_NSALAMT_CUSTRN
                              , ROUND(NVL(SUM(T.DLR_EXCH_NSALAMT)   
                              / DECODE(COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.DLR_EXCH_NSALAMT <> 0  THEN T.EXCH_SALES_CNT END)),0))        AS DLR_ARSE_NSALAMT_CUSTRN		      
                              , SUM(T.WON_PRMTN_NSALAMT)                                                                                                                                                                   AS WON_PRMTN_NSALAMT
                              , SUM(T.DLR_PRMTN_NSALAMT)                                                                                                                                                                   AS DLR_PRMTN_NSALAMT
                              , COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0  THEN T.PRMTN_NSALAMT_CNT END)                                                                                						   AS PRMTN_NSALAMT_CNT
                              , ROUND(NVL(SUM(T.WON_PRMTN_NSALAMT)  
                                / DECODE(COUNT(DISTINCT CASE WHEN T.WON_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.WON_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END)),0))  AS WON_PRMTN_NSALAMT_CUSTRN
                              , ROUND(NVL(SUM(T.DLR_PRMTN_NSALAMT)  
                                / DECODE(COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END), 0, NULL, COUNT(DISTINCT CASE WHEN T.DLR_PRMTN_NSALAMT <> 0 THEN T.PRMTN_NSALAMT_CNT END)),0))  AS DLR_PRMTN_NSALAMT_CUSTRN
                              , SUM(T.WON_LDFP_ACMLT_AMT)                                                                                                                                                                  AS WON_LDFP_ACMLT_AMT
                              , SUM(T.LDFP_ACMLT_CNT)                                                                                                                                                                      AS LDFP_ACMLT_CNT
                              , COUNT(DISTINCT CASE WHEN T.WON_LDFP_ACMLT_AMT IS NOT NULL AND T.WON_LDFP_ACMLT_AMT <> 0  THEN T.INTG_MEMB_NO END)                                                                          AS LDFP_ACMLT_CUST_NBR
                              , SUM(T.FREELDFP_USE_AMT)                                                                                                                                                                    AS FREELDFP_USE_AMT
                              , SUM(T.FREELDFP_USE_CNT)                                                                                                                                                                    AS FREELDFP_USE_CNT
                              , COUNT(DISTINCT CASE WHEN T.FREELDFP_USE_AMT   IS NOT NULL AND T.FREELDFP_USE_AMT <> 0    THEN T.INTG_MEMB_NO END)                                                                          AS FREELDFP_USE_CUST_NBR
                              , SUM(T.FREELDFP_ACMLT_AMT)                                                                                                                                                                  AS FREELDFP_ACMLT_AMT          /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                              , SUM(T.FREELDFP_ACMLT_CNT)                                                                                                                                                                  AS FREELDFP_ACMLT_CNT          /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                              , COUNT(DISTINCT CASE WHEN T.FREELDFP_ACMLT_AMT IS NOT NULL AND T.FREELDFP_ACMLT_AMT <> 0  THEN T.INTG_MEMB_NO END)                                                                          AS FREELDFP_ACLMLT_CUST_NBR
                              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS DC_AMT
                              , SUM(T.DC_CNT)                                                                                                                                                                              AS DC_CNT
                              , COUNT(DISTINCT CASE WHEN T.WON_TOT_DC_AMT     IS NOT NULL AND T.WON_TOT_DC_AMT <> 0      THEN T.INTG_MEMB_NO END)                                                                          AS BDN_CUST_NBR
                              , SUM(T.FGF_PRESTAT_AMT)                                                                                                                                                                     AS FGF_PRESTAT_AMT
                              , SUM(T.FGF_PRESTAT_CNT)                                                                                                                                                                     AS FGF_PRESTAT_CNT
                              , COUNT(DISTINCT CASE WHEN T.FGF_PRESTAT_AMT    IS NOT NULL AND T.FGF_PRESTAT_AMT <> 0     THEN T.INTG_MEMB_NO END)                                                                          AS FGF_PRESTAT_CUST_NBR
                              , MAX(T.ACMLTMN_OFFR_CUST)                                                                                                                                                                   AS ACMLTMN_OFFR_CUST_NBR     /* �����������Ǽ� */
                              , MAX(T.ACMLTMN_OFFR_CNT)                                                                                                                                                                    AS ACMLTMN_OFFR_CNT          /* ����������_�Ǽ� */
                              , MAX(T.DLR_ACMLTMN_OFFR_AMT)                                                                                                                                                                AS DLR_ACMLTMN_OFFR_AMT      /* ����������_�Ǽ� */ 
                              , SUM(T.ACMLTMN_USE_CNT)                                                                                                                                                                     AS ACMLTMN_USE_CNT
                              , SUM(T.WON_ACMLTMN_PYF_AMT)                                                                                                                                                                 AS WON_ACMLTMN_PYF_AMT
                              , COUNT(DISTINCT CASE WHEN T.WON_ACMLTMN_PYF_AMT IS NOT NULL AND T.WON_ACMLTMN_PYF_AMT <> 0 THEN T.INTG_MEMB_NO END)                                                                         AS ACMLTMN_USE_CUST_NBR
                              , SUM(T.TOT_PRESTAT_AMT)                                                                                                                                                                     AS TOT_PRESTAT_AMT
                              , SUM(T.PRESTAT_OURCOM_BDN_AMT)                                                                                                                                                              AS PRESTAT_OURCOM_BDN_AMT
                              , SUM(T.PRESTAT_ALYCO_BDN_AMT)                                                                                                                                                               AS PRESTAT_ALYCO_BDN_AMT
                              , ROUND(NVL(SUM(T.TOT_PRESTAT_AMT) / DECODE(SUM(T.WON_EXCH_NSALAMT),0,NULL,SUM(T.WON_EXCH_NSALAMT)),0)* 100 ,1)                                                                              AS TOT_PRESTAT_RATE /* ������(��ü) ADD */
                              , ROUND(NVL(SUM(T.PRESTAT_OURCOM_BDN_AMT) / DECODE(SUM(T.WON_EXCH_NSALAMT),0,NULL,SUM(T.WON_EXCH_NSALAMT)),0) * 100,1)                                                                       AS OURCOM_PRESTAT_RATE /* ������(���) */
                              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS TOT_BDN_AMT
                              , SUM(T.DC_OURCOM_BDN_AMT)                                                                                                                                                                   AS DC_OURCOM_BDN_AMT
                              , SUM(T.DC_ALYCO_BDN_AMT)                                                                                                                                                                    AS DC_ALYCO_BDN_AMT
                              , SUM(T.DC_CNT)                                                                                                                                                                              AS TOT_DC_CNT
                              , SUM(T.WON_TOT_DC_AMT)                                                                                                                                                                      AS WON_TOT_DC_AMT
                              , ROUND(NVL(SUM(T.WON_TOT_DC_AMT)     / DECODE(SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT),0,NULL,SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT)),0) * 100 ,1)                          AS DC_TOT_BDN_RATE /* ������(��ü) ADD */
                              , ROUND(NVL(SUM(T.DC_OURCOM_BDN_AMT)     / DECODE(SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT),0,NULL,SUM(T.WON_EXCH_NSALAMT) + SUM(T.WON_TOT_DC_AMT)),0) * 100 ,1)                        AS DC_OURCOM_BDN_RATE /* ������(���) */
                              , SUM(T.WON_ARSE_NSALAMT)                                                                                                                                                                    AS WON_ARSE_NSALAMT
                              , SUM(T.DLR_ARSE_NSALAMT)                                                                                                                                                                    AS DLR_ARSE_NSALAMT
                              , SUM(T.ONLN_WON_ARSE_NSALAMT)                                                                                                                                                               AS ONLN_WON_ARSE_NSALAMT
                              , SUM(T.ONLN_DLR_ARSE_NSALAMT)                                                                                                                                                               AS ONLN_DLR_ARSE_NSALAMT
                              , SUM(T.OFLN_WON_ARSE_NSALAMT)                                                                                                                                                               AS OFLN_WON_ARSE_NSALAMT
                              , SUM(T.OFLN_DLR_ARSE_NSALAMT)                                                                                                                                                               AS OFLN_DLR_ARSE_NSALAMT
                              , SUM(T.OMNI_WON_EXCH_NSALAMT)                                                                                                                                                               AS OMNI_WON_EXCH_NSALAMT
                              , SUM(T.OMNI_DLR_EXCH_NSALAMT)                                                                                                                                                               AS OMNI_DLR_EXCH_NSALAMT
                              , SUM(T.OMNI_WON_NSALAMT)                                                                                                                                                                    AS OMNI_WON_NSALAMT
                              , SUM(T.OMNI_DLR_NSALAMT)                                                                                                                                                                    AS OMNI_DLR_NSALAMT
                              , MAX(T.RGSTPSN_ID)                                                                                                                                                                          AS RGSTPSN_ID
                              , MAX(T.USR_NM)                                                                                                                                                                              AS USR_NM
                              , MAX(T.RGST_DEPTCD)                                                                                                                                                                         AS RGST_DEPTCD
                              , MAX(T.DEPT_NM)                                                                                                                                                                             AS DEPT_NM
                           FROM (  SELECT A3.LGPRCD                                                                                                           AS LGPRCD     
                                        , A1.LGPROMO_NM                                                                                                       AS LGPROMO_NM 
                                        , A3.MDPRCD                                                                                                           AS MDPRCD     
                                        , A2.MIDPROMO_NM                                                                                                      AS MIDPROMO_NM
                                        , A3.PRMTNCD                                                                                                          AS PRMTNCD    
                                        , A3.PRMTN_NM                                                                                                         AS PRMTN_NM       
                                        , A3.ONOFF_DVS_CD                                                                                                                     AS CHNL_TYPE_CD              /* ä�α���(1:��������,2:�¶���) */	  
                                        , A3.PRMTN_LGCSF_CD                                                                                                                   AS PRMTN_LGCSF_CD            /* ����з��ڵ� */
                                        , A4.PRMTN_LGCSF_NM                                                                                                                   AS PRMTN_LGCSF_NM            /* ����з��ڸ� */ 
                                        , A3.PRMTN_MDCSF_CD                                                                                                                   AS PRMTN_MDCSF_CD            /* ����ߺз��ڵ� */
                                        , A5.PRMTN_MDCSF_NM                                                                                                                   AS PRMTN_MDCSF_NM            /* ����ߺз��� */
                                        , A8.STR_CD
										, A7.CMPN_OFFER_NO                                                                                                                    AS CMPN_OFFER_NO             /* �����۹�ȣ */
                                        , A8.PRMTN_SECTRG_NO                                                                                                                  AS PRMTN_SECTRG_NO           /* �������ڵ� */
                                        , A7.PRMTN_APLY_STRT_AMT                                                                                                              AS PRMTN_APLY_STRT_AMT       /* ���������۱ݾ� */ 
                                        , A3.PRMTN_STRT_DT                                                                                                                    AS PRMTN_STRT_DT             /* ���������� */
                                        , A3.PRMTN_END_DT                                                                                                                     AS PRMTN_END_DT              /* ����������� */
                                        , A8.INTG_MEMB_NO                                                                                                                     AS INTG_MEMB_NO              /* ����ȸ����ȣ */
                                        , A8.WON_EXCH_NSALAMT                                                                                                                 AS WON_EXCH_NSALAMT          /* ��ȭ��ȯ�Ǽ������ */
                                        , A8.DLR_EXCH_NSALAMT                                                                                                                 AS DLR_EXCH_NSALAMT          /* �޷���ȯ�Ǽ������ */
                                        , (CASE WHEN A8.DLR_EXCH_NSALAMT IS NOT NULL THEN A8.INTG_MEMB_NO ELSE NULL END)                   									  AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                                        , A8.WON_PRMTN_NSALAMT                                                                                                                AS WON_PRMTN_NSALAMT         /* ��ȭ��������� */
                                        , A8.DLR_PRMTN_NSALAMT                                                                                                                AS DLR_PRMTN_NSALAMT         /* �޷���������� */
                                        , (CASE WHEN A8.DLR_PRMTN_NSALAMT IS NOT NULL THEN A8.INTG_MEMB_NO ELSE NULL END)                 									  AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                                        , A8.LDFP_ACMLT_AMT                                                                                                                   AS WON_LDFP_ACMLT_AMT        /* LDFPAY �����ݾ� */
                                        , A8.LDFP_ACMLT_CNT                                                                                                                   AS LDFP_ACMLT_CNT            /* LDFPAY �����Ǽ� */
                                        , A8.FREELDFP_USE_AMT                                                                                                                 AS FREELDFP_USE_AMT          /* ����LDFPAY���ݾ� */
                                        , A8.FREELDFP_USE_CNT                                                                                                                 AS FREELDFP_USE_CNT          /* ����LDFPAY���Ǽ� */
                                        , A8.FREELDFP_ACMLT_AMT                                                                                                               AS FREELDFP_ACMLT_AMT        /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                                        , A8.FREELDFP_ACMLT_CNT                                                                                                               AS FREELDFP_ACMLT_CNT        /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                                        , A8.DC_CNT                                                                                                                           AS DC_CNT                    /* ���ΰǼ� */
                                        , A8.FGF_PRESTAT_AMT                                                                                                                  AS FGF_PRESTAT_AMT           /* ����ǰ�����ݾ� */
                                        , A8.FGF_PRESTAT_CNT                                                                                                                  AS FGF_PRESTAT_CNT           /* ����ǰ�����Ǽ� */
                                        , NULL                                                                                                                                AS ACMLTMN_OFFR_CNT          /* �����������Ǽ�  */   
                                        , NULL                                                                                                                                AS DLR_ACMLTMN_OFFR_AMT      /* ��ȭ�����������ݾ�(�޷�)  */  
                                        , NULL                                                                                                                                AS ACMLTMN_USE_CNT           /* �����ݻ��Ǽ�  */  
                                        , NULL                                                                                                                                AS ACMLTMN_OFFR_CUST         /* �������������� */
                                        , NULL                                                                                                                                AS WON_ACMLTMN_PYF_AMT       /* ��ȭ�����ݰ����ݾ�  */ 
                                        , (A8.FGF_PRESTAT_AMT + A8.LDFP_ACMLT_AMT + A8.FREELDFP_USE_AMT)                                                                      AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü)(=����ǰ�����ݾ� + LDFPAY�����ݾ� + ����LDFPAY���ݾ�) */
                                        , A8.PRESTAT_OURCOM_BDN_AMT                                                                                                           AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���)(=�������δ�ݾ�) */
                                        , A8.PRESTAT_ALYCO_BDN_AMT                                                                                                            AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�)(=�������޻�δ�ݾ�) */                     
                                        , A8.DC_OURCOM_BDN_AMT                                                                                                                AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                                        , A8.DC_ALYCO_BDN_AMT                                                                                                                 AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */  
                                        , A8.WON_PRMTN_DC_AMT                                                                                                                 AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ�(��ȭ������αݾ�)  */
                                        , A8.WON_ARSE_NSALAMT                                                                                                                 AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ���߼������) */
                                        , A8.DLR_ARSE_NSALAMT                                                                                                                 AS DLR_ARSE_NSALAMT          /* �޷��������߸���(�޷����߼������) */
                                        , A8.WON_CROS_ARSE_NSALAMT                                                                                                            AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸��� */
                                        , A8.DLR_CROS_ARSE_NSALAMT                                                                                                            AS ONLN_DLR_ARSE_NSALAMT     /* �����������߸��� */  
                                        , NULL                                                                                                                                AS OFLN_WON_ARSE_NSALAMT     /* �������ο�ȭ���߼������ (=��ȭ�������߼������) */ 
                                        , NULL                                                                                                                                AS OFLN_DLR_ARSE_NSALAMT     /* �������δ޷����߼������ (=�޷��������߼������) */       
                                        , A8.OMNI_WON_EXCH_NSALAMT                                                                                                            AS OMNI_WON_EXCH_NSALAMT     /* �ȴϿ�ȭ��ȯ�Ǽ������ */                     
                                        , A8.OMNI_DLR_EXCH_NSALAMT                                                                                                            AS OMNI_DLR_EXCH_NSALAMT     /* �ȴϴ޷���ȯ�Ǽ������ */
                                        , A8.OMNI_WON_NSALAMT                                                                                                                 AS OMNI_WON_NSALAMT          /* �ȴϱ�ȯ�Ǽ������ */       
                                        , A8.OMNI_DLR_NSALAMT                                                                                                                 AS OMNI_DLR_NSALAMT          /* �ȴϴ޷�������� */
                                        , A3.RGSTPSN_ID                                                                                                                       AS RGSTPSN_ID                /* �����ID */
                                        , A9.USR_NM                                                                                                                           AS USR_NM                    /* ����ڸ� */
                                        , A3.RGST_DEPTCD                                                                                                                      AS RGST_DEPTCD               /* ��Ϻμ�ID */
                                        , A10.DEPT_NM                                                                                                                         AS DEPT_NM                   /* ��Ϻμ��� */
                                     FROM LDF_DW.D_LGPROMO A1
                                        , LDF_DW.D_MIDPROMO A2
                                        , LDF_DW.D_PRMTN A3
                                        , LDF_DW.D_PRMTN_LGCSF A4 
                                        , LDF_DW.D_PRMTN_MDCSF A5
                                        , LDF_DW.WL_LC_PRMTN_BNFT A6
                                        , LDF_DW.WL_LC_PRMTN_OFFER_SECT A7
                                        , LDF_DW.FL_MK_PRMTN_OFFER_ACTRSLT A8
                                        , LDF_DW.D_USR A9
                                        , LDF_DW.D_DEPT A10                                  
                                    WHERE 1=1
                                      AND A1.LGPRCD = A2.LGPRCD 
                                      AND A2.MDPRCD = A3.MDPRCD 
                                      AND A3.PRMTN_LGCSF_CD = A4.PRMTN_LGCSF_CD (+) 
                                      AND A3.PRMTN_MDCSF_CD = A5.PRMTN_MDCSF_CD (+) 
                                      AND A3.PRMTNCD = A6.PRMTNCD 
                                      AND A6.BNFT_OBJ_NO = A7.CMPN_OFFER_NO (+) 
                                      AND A3.PRMTNCD = A8.PRMTNCD 
                                      AND A7.CMPN_OFFER_NO = A8.OFFER_NO
                                      AND A7.PRMTN_SECTRG_NO = A8.PRMTN_SECTRG_NO
                                      AND A3.RGSTPSN_ID = A9.EMPNO (+) 
                                      AND A3.RGST_DEPTCD = A10.DEPTCD (+)
                                ]]><if test='prmtnDvsCd != null and prmtnDvsCd != "" and prmtncd != null and prmtncd != ""'>
                                   <choose>
                                      <when test='prmtnDvsCd == "1"'> <!-- ����� -->
                                      AND A3.LGPRCD         = #{prmtncd}        /* ��ȸ���� - ��籸�� ������� ��� ����ڵ� */     
                                      </when>
                                      <when test='prmtnDvsCd == "2"'> <!-- ����� -->
                                      AND A3.MDPRCD         = #{prmtncd}        /* ��ȸ���� - ��籸�� ������� ��� ����ڵ� */
                                      </when>
                                      <when test='prmtnDvsCd == "3"'> <!-- ����� -->
                                      AND A3.PRMTNCD        = #{prmtncd}       /* ��ȸ���� - ��籸�� ������� ��� ����ڵ� */
                                      </when>
                                   </choose>
                                   </if>
                                   <if test='inqryStrtDt != null and inqryStrtDt != ""'>
                                      AND A8.STD_DT        >= #{inqryStrtDt}           /* ��ȸ ������ */
                                   </if>   
                                   <if test='inqryEndDt != null and inqryEndDt != ""'>
                                      AND A8.STD_DT        <![CDATA[<=]]> #{inqryEndDt}           /* ��ȸ ������ */
                                   </if>
                                            /* ��ȸ���� */
                                 <if test='(strCd != null and strCd != "") or (strCds != null) or (biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != "") or (biznsStrLoctnDvsCds != null)'>         
                                      AND A3.PRMTNCD   IN (SELECT PRMTNCD 
                                                             FROM LDF_DW.WL_LC_PRMTN_OFFR_CNDT A3
                                                                , LDF_DW.D_STR A4
                                                            WHERE 1                          = 1
                                                              AND A3.PRMTN_CNDT_VAL          = A4.STR_CD
                                                              AND PRMTN_OFFR_CNDT_CD         = '01'
                                                              AND CHNL_TYPE_CD               = '02'
                                                   <if test='strCd != null and strCd != ""'>
                                                              AND A3.PRMTN_CNDT_VAL          = #{strCd} /* ��ȸ���� - ���� */
                                                   </if>
                                                   <if test='strCds != null'>
                                                              AND A3.PRMTN_CNDT_VAL         IN <foreach collection="strCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ���� */
                                                   </if>
                                                   <if test='biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != ""'>
                                                              AND A4.BIZNS_STR_LOCTN_DVS_CD  = #{biznsStrLoctnDvsCd} /* ��ȸ���� - ��������ġ���� */
                                                   </if>
                                                   <if test='biznsStrLoctnDvsCds != null'>
                                                              AND A4.BIZNS_STR_LOCTN_DVS_CD IN <foreach collection="biznsStrLoctnDvsCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ��������ġ���� */
                                                   </if>
                                                    )  
                                 </if>
                               UNION ALL
                              SELECT /* FE_MK_����OFFER�� */
                                     A1.LGPRCD                                                 AS LGPRCD
                                   , A2.LGPROMO_NM                                             AS LGPROMO_NM
                                   , A1.MDPRCD                                                 AS MDPRCD
                                   , A3.MIDPROMO_NM                                            AS MIDPROMO_NM
                                   , A1.PRMTNCD                                                AS PRMTNCD 
                                   , A1.PRMTN_NM                                               AS PRMTN_NM
                                   , A1.ONOFF_DVS_CD                                           AS CHNL_TYPE_CD
                                   , A1.PRMTN_LGCSF_CD                                         AS PRMTN_LGCSF_CD
                                   , A4.PRMTN_LGCSF_NM                                         AS PRMTN_LGCSF_NM
                                   , A1.PRMTN_MDCSF_CD                                         AS PRMTN_MDCSF_CD
                                   , A5.PRMTN_MDCSF_NM                                         AS PRMTN_MDCSF_NM
                                   , A1.STR_CD
								   , A9.CMPN_OFFER_NO                                          AS CMPN_OFFER_NO             /* �����۹�ȣ */
                                   , CAST(A9.PRMTN_SECTRG_NO AS NUMBER(20,0))                   AS PRMTN_SECTRG_NO           /* �������ڵ� */
                                   , A9.PRMTN_APLY_STRT_AMT                                    AS PRMTN_APLY_STRT_AMT       /* ���������۱ݾ� */ 
                                   , A1.PRMTN_STRT_DT                                          AS PRMTN_STRT_DT
                                   , A1.PRMTN_END_DT                                           AS PRMTN_END_DT
                                   , NULL                                                      AS INTG_MEMB_NO              /* ����ȸ����ȣ */
                                   , 0                                                         AS WON_EXCH_NSALAMT          /* ��ȭ��ȯ�Ǽ������ */
                                   , 0                                                         AS DLR_EXCH_NSALAMT          /* �޷���ȯ�Ǽ������ */
                                   , NULL                                                      AS EXCH_SALES_CNT            /* ��ȯ�Ǹ���_�������� */
                                   , 0                                                         AS WON_PRMTN_NSALAMT         /* ��ȭ��������� */
                                   , 0                                                         AS DLR_PRMTN_NSALAMT         /* �޷���������� */
                                   , NULL                                                      AS PRMTN_NSALAMT_CNT         /* ������_�������� */
                                   , 0                                                         AS WON_LDFP_ACMLT_AMT        /* LDFPAY �����ݾ� */
                                   , 0                                                         AS LDFP_ACMLT_CNT            /* LDFPAY �����Ǽ� */
                                   , 0                                                         AS FREELDFP_USE_AMT          /* ����LDFPAY���ݾ� */
                                   , 0                                                         AS FREELDFP_USE_CNT          /* ����LDFPAY���Ǽ� */
                                   , 0                                                         AS FREELDFP_ACMLT_AMT        /* ����LDFPAY�����ݾ�(����LDFPAY�����ݾ�) */
                                   , 0                                                         AS FREELDFP_ACMLT_CNT        /* ����LDFPAY�����Ǽ�(����LDFPAY�����Ǽ�) */ 
                                   , 0                                                         AS DC_CNT                    /* ���ΰǼ� */
                                   , 0                                                         AS FGF_PRESTAT_AMT           /* ����ǰ�����ݾ� */
                                   , 0                                                         AS FGF_PRESTAT_CNT           /* ����ǰ�����Ǽ� */
                                   , 0                                                         AS ACMLTMN_OFFR_CNT          /* �����������Ǽ� */
                                   , A1.DLR_ACMLTMN_OFFR_AMT                                   AS DLR_ACMLTMN_OFFR_AMT      /* �����������ݾ�(�޷�) */
                                   , A1.ACMLTMN_OFFR_CNT                                       AS ACMLTMN_USE_CNT           /* �����ݻ��Ǽ� */
                                   , A1.ACMLTMN_OFFR_CUST_NBR                                  AS ACMLTMN_OFFR_CUST         /* �������������� */
                                   , 0                                                         AS WON_ACMLTMN_PYF_AMT       /* ��ȭ�����ݰ����ݾ�  */  
                                   , 0                                                         AS TOT_PRESTAT_AMT           /* �����ݾ�(��ü)(=���+���޻�) */
                                   , 0                                                         AS PRESTAT_OURCOM_BDN_AMT    /* �����ݾ�(���)(=�������δ�ݾ�) */
                                   , 0                                                         AS PRESTAT_ALYCO_BDN_AMT     /* �����ݾ�(���޻�)(=�������޻�δ�ݾ�) */                     
                                   , 0                                                         AS DC_OURCOM_BDN_AMT         /* ���αݾ�(���) */
                                   , 0                                                         AS DC_ALYCO_BDN_AMT          /* ���αݾ�(���޻�) */  
                                   , 0                                                         AS WON_TOT_DC_AMT            /* ��ȭ�����αݾ�  */ 
                                   , 0                                                         AS WON_ARSE_NSALAMT          /* �������߸���(��ȭ���߼������) */
                                   , 0                                                         AS DLR_ARSE_NSALAMT          /* �޷��������߸���(�޷����߼������) */
                                   , 0                                                         AS ONLN_WON_ARSE_NSALAMT     /* �¶������߸��� */
                                   , 0                                                         AS ONLN_DLR_ARSE_NSALAMT     /* �����������߸��� */  
                                   , 0                                                         AS OFLN_WON_ARSE_NSALAMT     /* �������ο�ȭ���߼������ (=��ȭ�������߼������) */ 
                                   , 0                                                         AS OFLN_DLR_ARSE_NSALAMT     /* �������δ޷����߼������ (=�޷��������߼������) */       
                                   , 0                                                         AS OMNI_WON_EXCH_NSALAMT     /* �ȴϿ�ȭ��ȯ�Ǽ������ */                     
                                   , 0                                                         AS OMNI_DLR_EXCH_NSALAMT     /* �ȴϴ޷���ȯ�Ǽ������ */
                                   , 0                                                         AS OMNI_WON_NSALAMT          /* �ȴϱ�ȯ�Ǽ������ */       
                                   , 0                                                         AS OMNI_DLR_NSALAMT          /* �ȴϴ޷�������� */
                                   , A1.RGSTPSN_ID                                             AS RGSTPSN_ID                /* �����ID */
                                   , A6.USR_NM                                                 AS USR_NM                    /* ����ڸ� */
                                   , A1.RGST_DEPTCD                                            AS RGST_DEPTCD               /* ��Ϻμ�ID */
                                   , A7.DEPT_NM                                                AS DEPT_NM                   /* ��Ϻμ��� */
                                FROM (SELECT /*+ PARALLEL(4) USE_HASH(B1,B4)  FULL(B1) FULL(B4)*/
                                             B1.PRMTNCD                      AS PRMTNCD 
                                           , B1.PRMTN_NM                     AS PRMTN_NM
                                           , B1.STR_CD                       AS STR_CD
                                           , MAX(B1.LGPRCD)                  AS LGPRCD
                                           , MAX(B1.MDPRCD)                  AS MDPRCD
                                           , MAX(B1.PRMTN_STRT_DT)           AS PRMTN_STRT_DT 
                                           , MAX(B1.PRMTN_END_DT)            AS PRMTN_END_DT 
                                           , MAX(B1.ONOFF_DVS_CD)            AS ONOFF_DVS_CD 
                                           , MAX(B1.PRMTN_LGCSF_CD)          AS PRMTN_LGCSF_CD 
                                           , MAX(B1.PRMTN_MDCSF_CD)          AS PRMTN_MDCSF_CD 
                                           , MAX(B1.RGSTPSN_ID)              AS RGSTPSN_ID 
                                           , MAX(B1.RGST_DEPTCD)             AS RGST_DEPTCD 
                                           , COUNT(DISTINCT B4.INTG_MEMB_NO) AS ACMLTMN_OFFR_CUST_NBR /* �����������Ǽ� */
                                           , SUM(B4.OFFER_PRESTAT_CNT)       AS ACMLTMN_OFFR_CNT /* ����������_�Ǽ� */
                                           , SUM(B4.DLR_OFFER_PRESTAT_AMT)   AS DLR_ACMLTMN_OFFR_AMT /* �޷������������ݾ� */        
                                        FROM (SELECT B3.PRMTNCD
                                                   , B3.PRMTN_NM
                                                   , B3.LGPRCD
                                                   , B3.MDPRCD
                                                   , B3.PRMTN_STRT_DT
                                                   , B3.PRMTN_END_DT
                                                   , B3.ONOFF_DVS_CD
                                                   , B3.PRMTN_LGCSF_CD
                                                   , B3.PRMTN_MDCSF_CD
                                                   , B7.PRMTN_CNDT_VAL       AS STR_CD
                                                   , B3.RGSTPSN_ID
                                                   , B3.RGST_DEPTCD
                                                   , B6.BNFT_OBJ_NO      AS ONLN_OFFER_NO  /* ���ô���ȣ */
                                                   , B6.PRMTN_BNFT_NO    AS PRMTN_BNFT_NO  /* ������ù�ȣ */
                                                FROM LDF_DW.D_PRMTN B3
                                                   , LDF_DW.WL_LC_PRMTN_BNFT B6
                                                   , LDF_DW.WL_LC_PRMTN_OFFR_CNDT B7
                                               WHERE 1=1
                                                 AND B3.PRMTNCD        = B6.PRMTNCD 
	     			  	          	             AND B3.PRMTNCD        = B7.PRMTNCD
                                                 AND B3.PRMTN_LGCSF_CD = '007' /* ������ */
                                                 AND B7.PRMTN_OFFR_CNDT_CD   = '01'          /* ���������ڵ� */
                                <if test='prmtnDvsCd != null and prmtnDvsCd != "" and prmtncd != null and prmtncd != ""'>
                                    <choose>
                                         <when test='prmtnDvsCd == "1"'> <!-- ����� -->
                                                 AND B3.LGPRCD         = #{prmtncd} /* ��ȸ���� - ��籸�� ������� ��� ����ڵ� */
                                         </when>
                                         <when test='prmtnDvsCd == "2"'> <!-- ����� -->
                                                 AND B3.MDPRCD       = #{prmtncd}       /* �������� - ������ڵ� */
                                         </when>
                                         <when test='prmtnDvsCd == "3"'> <!-- ����� -->
                                                 AND B3.PRMTNCD      = #{prmtncd}         /* ��ȸ���� - ��籸�� ������� ��� ����ڵ� */
                                         </when>
                                    </choose>
                                </if>
                                             ) B1
                                           , LDF_DW.FE_MK_BNFT_OFFER_DTL B4
                                       WHERE 1=1
                                         AND B4.STD_DT       BETWEEN B1.PRMTN_STRT_DT AND B1.PRMTN_END_DT 
                                         AND B4.STD_TM_VAL        >= '00'
                                         AND B4.ONLN_OFFER_NO      = B1.ONLN_OFFER_NO 
                                         AND B4.PRMTN_BNFT_NO      = B1.PRMTN_BNFT_NO 
                                         AND B4.OFFER_PRESTAT_CNT <![CDATA[<>]]> 0 /* �����Ǽ� 0�� �ƴѰ�� */
                                <if test='inqryStrtDt != null and inqryStrtDt != ""'>
                                         AND B4.STD_DT <![CDATA[>=]]> #{inqryStrtDt}  /* ��ȸ ������ */
                                </if>
                                <if test='inqryEndDt != null and inqryEndDt != ""'>
                                         AND B4.STD_DT <![CDATA[<=]]> #{inqryEndDt}  /* ��ȸ ������ */
                                </if>
                                       GROUP BY B1.PRMTNCD
                                              , B1.PRMTN_NM
                                              , B1.STR_CD    
                                     ) A1
                                     , LDF_DW.D_LGPROMO A2
                                     , LDF_DW.D_MIDPROMO A3
                                     , LDF_DW.D_PRMTN_LGCSF A4
                                     , LDF_DW.D_PRMTN_MDCSF A5
                                     , LDF_DW.D_USR A6
                                     , LDF_DW.D_DEPT A7
                                     , LDF_DW.WL_LC_PRMTN_BNFT A8       /* WL_LC_������� */
                                     , LDF_DW.WL_LC_PRMTN_OFFER_SECT A9 /* WL_LC_���OFFER���� */
                                 WHERE 1=1
                                   AND A1.LGPRCD         = A2.LGPRCD 
                                   AND A1.MDPRCD         = A3.MDPRCD
                                   AND A1.PRMTN_LGCSF_CD = A4.PRMTN_LGCSF_CD (+)
                                   AND A1.PRMTN_MDCSF_CD = A5.PRMTN_MDCSF_CD (+)
                                   AND A1.RGSTPSN_ID     = A6.EMPNO (+)
                                   AND A1.RGST_DEPTCD    = A7.DEPTCD (+)
                                   AND A1.PRMTNCD = A8.PRMTNCD
                                   AND A8.BNFT_OBJ_NO = A9.CMPN_OFFER_NO (+)
                               <if test='(strCd != null and strCd != "") or (strCds != null) or (biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != "") or (biznsStrLoctnDvsCds != null)'>
                                   AND A1.PRMTNCD      IN (SELECT PRMTNCD 
                                                             FROM LDF_DW.WL_LC_PRMTN_OFFR_CNDT A3
                                                                , LDF_DW.D_STR A4
                                                            WHERE 1                          = 1
                                                              AND A3.PRMTN_CNDT_VAL          = A4.STR_CD
                                                              AND A3.PRMTN_OFFR_CNDT_CD      = '01'
                                                              AND A3.CHNL_TYPE_CD            = '02'
                                   <if test='strCd != null and strCd != ""'>
                                                                    AND A3.PRMTN_CNDT_VAL          = #{strCd} /* ��ȸ���� - ���� */
                                   </if>
                                   <if test='strCds != null'>
                                                                    AND A3.PRMTN_CNDT_VAL         IN <foreach collection="strCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ���� */
                                   </if>
                                   <if test='biznsStrLoctnDvsCd != null and biznsStrLoctnDvsCd != ""'>
                                                                    AND A4.BIZNS_STR_LOCTN_DVS_CD  = #{biznsStrLoctnDvsCd} /* ��ȸ���� - ��������ġ���� */
                                   </if>
                                   <if test='biznsStrLoctnDvsCds != null'>
                                                                    AND A4.BIZNS_STR_LOCTN_DVS_CD IN <foreach collection="biznsStrLoctnDvsCds" item="item" open="(" close=")" separator=",">#{item}</foreach> /* ��ȸ���� - ��������ġ���� */
                                   </if>
                                   )
                               </if>
                                                        
                       ) T   
                 WHERE 1=1
                 GROUP BY T.LGPRCD                                                                                                                                                          
                     , T.LGPROMO_NM                                                                                                                                                     
                     , T.MDPRCD                                                                                                                                                          
                     , T.MIDPROMO_NM                                                                                                                                                    
                     , T.PRMTNCD                                                                                                                                                         
                     , T.PRMTN_NM 
                     , T.STR_CD
                     , T.CMPN_OFFER_NO
                     , T.PRMTN_SECTRG_NO
                     , T.PRMTN_APLY_STRT_AMT 
           ) A
       GROUP BY A.LGPRCD                            
             , A.LGPROMO_NM                       
             , A.MDPRCD                           
             , A.MIDPROMO_NM                  
             , A.PRMTNCD                          
             , A.PRMTN_NM
             , A.STR_CD
             , A.PRMTN_APLY_STRT_AMT
        ) M
